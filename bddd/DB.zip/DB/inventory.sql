-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 12, 2016 at 04:50 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inventory`
--
CREATE DATABASE IF NOT EXISTS `inventory` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `inventory`;

-- --------------------------------------------------------

--
-- Table structure for table `im_consume`
--

CREATE TABLE IF NOT EXISTS `im_consume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `remarks` text NOT NULL,
  `cre_by` tinyint(4) NOT NULL,
  `cre_date` varchar(20) NOT NULL,
  `user_id` tinyint(4) NOT NULL,
  `image_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `im_consume`
--

INSERT INTO `im_consume` (`id`, `parent_id`, `category_id`, `item_id`, `quantity`, `remarks`, `cre_by`, `cre_date`, `user_id`, `image_id`) VALUES
(1, 52, 66, 29, 1, 'Unserviceable', 0, '22/03/0017', 4, 17),
(2, 52, 99, 134, 5, 'Use Computer', 0, '05/04/0017', 5, 256),
(3, 52, 99, 134, 4, 'Use Computer', 0, '05/04/0017', 4, 256);

-- --------------------------------------------------------

--
-- Table structure for table `im_distribution`
--

CREATE TABLE IF NOT EXISTS `im_distribution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `remarks` text NOT NULL,
  `cre_by` tinyint(4) NOT NULL,
  `cre_date` varchar(20) NOT NULL,
  `user_id` tinyint(4) NOT NULL,
  `image_id` int(11) DEFAULT NULL,
  `stock_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=366 ;

--
-- Dumping data for table `im_distribution`
--

INSERT INTO `im_distribution` (`id`, `parent_id`, `category_id`, `item_id`, `quantity`, `remarks`, `cre_by`, `cre_date`, `user_id`, `image_id`, `stock_id`) VALUES
(3, 52, 99, 4, 2, 'Maj Bozlur Roshid', 0, '13/03/2016', 5, 9, NULL),
(4, 52, 99, 4, 1, 'Maj Zakir Hossain', 0, '13/03/2016', 3, 9, NULL),
(5, 52, 99, 4, 1, 'Maj Farzad Ehsan', 0, '13/03/2016', 4, 9, NULL),
(7, 52, 99, 21, 2, 'Sgt Mizan', 0, '13/03/2016', 4, 184, NULL),
(8, 52, 99, 23, 2, 'Sgt Rokanuzzaman', 0, '13/03/2016', 5, 11, NULL),
(10, 52, 66, 112, 8, 'sgt Rokanuzzaman', 0, '13/03/2016', 5, 15, NULL),
(11, 52, 53, 28, 3, 'Sgt Rokanuzzaman', 0, '13/03/2016', 5, 16, NULL),
(12, 52, 53, 28, 1, 'Sgt Rokanuzzaman', 0, '13/03/2016', 3, 16, NULL),
(13, 52, 53, 28, 4, 'Maj Ripun,Maj Shazzad,Maj Farzad,Office', 0, '13/03/2016', 4, 16, NULL),
(14, 52, 99, 22, 2, '1 x Co, 1 x Sgt Rokanuzzaman', 0, '08/12/2015', 5, 21, NULL),
(15, 52, 99, 22, 3, 'sgt mizan', 0, '08/12/2015', 4, 21, NULL),
(16, 52, 66, 24, 2, 'Sgt Rokanuzzaman', 0, '08/12/2015', 5, 12, NULL),
(18, 52, 66, 29, 1, '1 x Maj bozlur Rahman', 0, '04/01/2016', 5, 17, NULL),
(19, 52, 66, 29, 0, '1 x Sgt Mizan', 0, '03/01/2016', 4, 17, NULL),
(21, 52, 53, 25, 1, 'Lcpl Iqbql', 0, '08/12/2015', 3, 13, NULL),
(22, 52, 53, 25, 4, 'Sgt Mizanur Rahman', 0, '24/2/2016', 4, 13, NULL),
(23, 52, 53, 25, 3, 'Sgt Rokanuzzaman', 0, '24/2/2016', 5, 13, NULL),
(24, 52, 53, 25, 2, '1 X Cpl Sharif 1 x WO Mostofa', 0, '24/2/2016', 1, 13, NULL),
(25, 52, 99, 116, 3, 'Sgt Rokanuzzaman', 0, '08/12/2015', 5, 185, NULL),
(26, 52, 99, 116, 1, 'Sgt Mizan', 0, '08/12/2015', 4, 185, NULL),
(27, 52, 99, 31, 1, 'Sgt Mizan', 0, '08/12/2015', 4, 18, NULL),
(28, 52, 99, 31, 3, 'Sgt Rokanuzzaman', 0, '24/2/2016', 5, 18, NULL),
(29, 52, 53, 32, 5, 'Lcpl Iqbal', 0, '09/03/2016', 4, 19, NULL),
(30, 52, 53, 32, 5, 'Lcpl Iqbal', 0, '09/03/2016', 5, 19, NULL),
(31, 52, 53, 32, 5, 'Lcpl Iqbal', 0, '09/03/2016', 3, 19, NULL),
(32, 52, 53, 32, 1, 'Wo Mostofa', 0, '08/12/2015', 1, 19, NULL),
(33, 52, 99, 35, 1, 'Cpl Sharif', 0, '10/12/2015', 2, 22, NULL),
(34, 52, 54, 46, 3, '1 x Co, 1 X Maj Bozlur Rahman, 1 X Mark', 0, '20/01/2016', 5, 23, NULL),
(35, 52, 54, 46, 1, '1 x Maj Zakir', 0, '20/01/2016', 3, 23, NULL),
(36, 52, 54, 46, 3, '1 x Riponuzzaman 1 x Farzad, 1 x Shazzad', 0, '24/2/2016', 4, 23, NULL),
(37, 52, 54, 46, 1, '1 x Admin officer', 0, '24/2/2016', 1, 23, NULL),
(38, 52, 54, 46, 1, '1 x Maj Arif', 0, '20/01/2016', 2, 23, NULL),
(39, 52, 54, 47, 3, '1 x Farzad Ahsan', 0, '20/01/2016', 3, 24, NULL),
(40, 52, 54, 47, 3, '1 x Farzad Ahsan', 0, '20/01/2016', 5, 24, NULL),
(41, 52, 54, 47, 3, '1 x Farzad Ahsan', 0, '20/01/2016', 4, 24, NULL),
(42, 52, 54, 47, 1, '1 x Admin Officer', 0, '20/01/2016', 1, 24, NULL),
(43, 52, 54, 48, 1, '1 x sgt Mizan', 0, '20/01/2016', 4, 25, NULL),
(44, 52, 54, 48, 2, '1 x Maj Bozlur Rashid, 1 x Sgt Rokanuzzaman', 0, '20/01/2016', 5, 25, NULL),
(45, 52, 54, 49, 5, '1 x Maj Bozlur Rahman', 0, '20/01/2016', 5, 28, NULL),
(46, 52, 54, 49, 1, '1 x Zakir', 0, '20/01/2016', 3, 28, NULL),
(47, 52, 54, 49, 1, '1 x Maj Arif', 0, '20/01/2016', 2, 28, NULL),
(48, 52, 54, 49, 1, '1 X Shazzad', 0, '20/01/2016', 4, 28, NULL),
(49, 52, 54, 50, 2, '1 x Wo Saiful, 1 X Sgt Mizan', 0, '26/01/2016', 4, 29, NULL),
(50, 52, 54, 51, 1, ' 1 x WO Shahabuddin', 0, '26/01/2016', 4, 30, NULL),
(51, 52, 54, 51, 1, '1 x Lcpl Masum Billa', 0, '26/01/2016', 2, 30, NULL),
(52, 52, 53, 119, 1, '1 x Snk Mahfuzur Rahman', 0, '10/03/2016', 2, 241, NULL),
(53, 52, 53, 119, 1, '1 x Lcpl Iqbal ', 0, '10/03/2016', 3, 241, NULL),
(54, 68, 70, 5, 1, 'Lcpl Masum Billah', 0, '19/02/2016', 2, 150, NULL),
(55, 68, 69, 7, 1, 'Lcpl Masum Billah', 0, '19/02/2016', 2, 152, NULL),
(56, 52, 99, 21, 3, 'Sgt Rokonuzzaman ', 0, '23/12/2015', 5, 183, NULL),
(57, 52, 99, 121, 2, 'Sgt Mizan, User 1 x Wo Shahabuddin 1 x Wo Shaiful ', 0, '16/03/2016', 4, 244, NULL),
(58, 52, 99, 122, 2, 'sgt mizan. ', 0, '16/03/2016', 4, 245, NULL),
(59, 68, 102, 6, 1, 'Lcpl Masum Billah', 0, '23/02/2016', 2, 151, NULL),
(60, 68, 70, 8, 1, 'Lcpl Masum Billah', 0, '23/02/2016', 2, 153, NULL),
(61, 68, 70, 9, 1, 'Lcpl Masum Billah', 0, '23/02/2016', 2, 154, NULL),
(62, 52, 66, 10, 1, 'Lcpl Masum Billah', 0, '23/02/2016', 2, 155, NULL),
(63, 68, 70, 12, 1, 'Lcpl Masum Billah', 0, '23/02/2016', 2, 157, NULL),
(64, 68, 102, 13, 2, 'Lcpl Masum Billah', 0, '23/02/2016', 2, 158, NULL),
(65, 68, 70, 14, 10, 'Lcpl Masum Billah', 0, '23/02/2016', 2, 159, NULL),
(66, 68, 70, 11, 1, 'Lcpl Masum Billah', 0, '23/02/2016', 2, 156, NULL),
(67, 68, 70, 19, 1, 'Lcpl Masum Billah', 0, '23/02/2016', 2, 248, NULL),
(68, 68, 69, 53, 1, 'Lcpl Iqbql', 0, '16/03/2016', 3, 32, NULL),
(69, 76, 77, 54, 2, ' Use Only for CO', 0, '21/02/2016', 5, 7, NULL),
(70, 76, 77, 54, 1, 'Use for Maj Farzad Ahasan', 0, '21/02/2016', 4, 8, NULL),
(71, 52, 66, 26, 3, '1 x Maj Bozlur Rashid, 1 x Co, 1 x Mark', 0, '08/02/2016', 5, 14, NULL),
(72, 52, 66, 26, 3, '1 x Maj  Farzad, 1 x Maj Shazzad, 1 x Maj Ripon', 0, '08/12/2015', 4, 14, NULL),
(73, 52, 66, 26, 2, '2 x Maj Zakir', 0, '08/12/2015', 3, 14, NULL),
(74, 52, 66, 26, 1, '1 x Maj Arif', 0, '24/2/2016', 2, 14, NULL),
(77, 81, 88, 65, 3, '1 x Maj Farzad, 1 x Maj shazad 1 x Ripon', 0, '06/12/2015', 4, 46, NULL),
(78, 81, 88, 65, 2, '1 x Co, 1 x Maj Bojlur Rasid', 0, '06/12/2015', 5, 46, NULL),
(79, 81, 88, 65, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 46, NULL),
(80, 81, 88, 66, 3, '1 x Maj Farzad, 1 x Shazad, 1 x Ripon', 0, '06/12/2015', 4, 47, NULL),
(81, 81, 88, 66, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 212, NULL),
(82, 81, 88, 66, 2, '1 x co, 1 x Maj Rashid', 0, '06/12/2015', 5, 47, NULL),
(83, 81, 88, 67, 3, '1 x Maj Farzad. 1 x Shazad, 1 x Ripon', 0, '06/12/2015', 4, 48, NULL),
(84, 81, 88, 67, 2, '1 x Co, 1 x Maj Rashid', 0, '06/12/2015', 5, 48, NULL),
(85, 81, 88, 67, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 48, NULL),
(86, 81, 88, 68, 3, '1 x Maj Farzad. 1 x Shazad, 1 x Ripon', 0, '06/12/2015', 4, 49, NULL),
(87, 81, 88, 68, 2, '1 x Co, 1 x Maj Rashid', 0, '06/12/2015', 5, 49, NULL),
(88, 81, 88, 68, 1, '1 X Maj zakir', 0, '06/12/2015', 3, 49, NULL),
(89, 81, 88, 69, 3, '1 x Maj Farzad. 1 x Shazad, 1 x Ripon', 0, '06/12/2015', 4, 132, NULL),
(90, 81, 88, 69, 2, '1 x Co, 1 x  Maj Rashid', 0, '06/12/2015', 5, 132, NULL),
(91, 81, 88, 69, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 132, NULL),
(92, 81, 88, 70, 2, '1 x Maj Farzad. 1 x Ripon', 0, '06/12/2015', 4, 133, NULL),
(93, 81, 88, 70, 2, '1 x Co, 1 x Maj Rashid', 0, '06/12/2015', 5, 133, NULL),
(94, 81, 88, 70, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 133, NULL),
(95, 81, 88, 71, 3, '1 x Maj Farzad. 1 x Shazad, 1 x Ripon', 0, '06/12/2015', 4, 134, NULL),
(96, 81, 88, 71, 2, '1 x Co, 1 x Rashid', 0, '06/12/2015', 5, 134, NULL),
(97, 81, 88, 71, 1, '1 x Zakir', 0, '06/12/2015', 3, 134, NULL),
(98, 81, 88, 80, 4, '1 x CO, 1 x Bozlur Rashed', 0, '06/12/2015', 5, 145, NULL),
(99, 81, 88, 72, 3, '1 x Maj Farzad, 1 x Maj shazzath, 1 x Maj Ripon', 0, '06/12/2015', 4, 135, NULL),
(100, 81, 88, 72, 2, '1 x Co, 1 x Maj Rashid', 0, '06/12/2015', 5, 135, NULL),
(101, 81, 88, 72, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 135, NULL),
(102, 81, 88, 73, 3, '1 x Maj Farzad, 1 x Maj shazzath, 1 x Maj Ripon', 0, '06/12/2015', 4, 136, NULL),
(103, 81, 88, 73, 2, '1 x Co, 1 x Maj Rashid', 0, '06/12/2015', 5, 136, NULL),
(104, 81, 88, 73, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 136, NULL),
(105, 81, 88, 74, 3, '1 x Maj Farzad, 1 x Maj shazzath, 1 x Maj Ripon', 0, '06/12/2015', 4, 137, NULL),
(106, 81, 88, 74, 2, '1 x Co, 1 x Maj Rashid', 0, '06/12/2015', 5, 137, NULL),
(107, 81, 88, 74, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 137, NULL),
(108, 81, 88, 76, 3, '1 x Maj Farzad, 1 x Maj shazzath, 1 x Maj Ripon', 0, '06/12/2015', 4, 138, NULL),
(109, 81, 88, 76, 2, '1 x Co, 1 x Maj Rashid', 0, '06/12/2015', 5, 138, NULL),
(110, 81, 88, 76, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 138, NULL),
(111, 81, 88, 59, 10, '1 st wo rasad', 0, '27/11/2015', 2, 39, NULL),
(112, 81, 83, 58, 0, 'Maj Bozlur Rashed', 0, '06/12/2015', 5, 38, NULL),
(115, 81, 88, 84, 3, '1 x Maj Farzad, 1 x Maj Shazzad, 1 x Maj Ripon', 0, '06/12/2015', 4, 141, NULL),
(116, 81, 88, 84, 2, '1 x Co, 1 x Maj Bozlur Rashid', 0, '06/12/2015', 5, 141, NULL),
(117, 81, 88, 84, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 141, NULL),
(118, 81, 88, 77, 3, '1 x Maj Farzad, 1 x Maj Shazzad, 1 x Maj Ripon', 0, '06/12/2015', 4, 140, NULL),
(119, 81, 88, 77, 2, '1 x CO, 1 x Maj Bozlur Rashid', 0, '06/12/2015', 5, 140, NULL),
(120, 81, 88, 77, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 140, NULL),
(121, 81, 83, 78, 3, '1 x Maj Farzad, 1 x Maj Shazzad, 1 x Maj Ripon', 0, '06/12/2015', 4, 142, NULL),
(122, 81, 83, 78, 2, '1 x Co, 1 x maj Bozlur rashid', 0, '06/12/2015', 5, 142, NULL),
(123, 81, 83, 78, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 142, NULL),
(124, 81, 83, 91, 3, '1 x Maj Farzad, 1 x Maj Shazzad, 1 x Maj Ripon', 0, '06/12/2015', 4, 143, NULL),
(125, 81, 83, 91, 2, '1 x Co, 1 x maj Bozlur Rashid', 0, '06/12/2015', 5, 143, NULL),
(126, 81, 83, 91, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 143, NULL),
(127, 81, 88, 79, 3, '1 x Maj Farzad, 1 x Maj Shazzad, 1 x Maj Ripon', 0, '06/12/2015', 4, 144, NULL),
(128, 81, 88, 79, 2, '1 x Co, 1 x Maj Bozlur Rashid', 0, '06/12/2015', 5, 144, NULL),
(129, 81, 88, 79, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 144, NULL),
(130, 81, 88, 80, 3, '1 x Maj Farzad, 1 x Maj Shazzad, 1 x Maj Ripon', 0, '06/12/2015', 4, 145, NULL),
(131, 81, 88, 80, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 145, NULL),
(132, 81, 88, 81, 3, '1 x Maj Farzad, 1 x Maj Shazzad, 1 x Maj Ripon', 0, '06/12/2015', 4, 146, NULL),
(133, 81, 88, 81, 2, '1 x CO, 1 x Maj Bozlur Rashid', 0, '06/12/2015', 5, 146, NULL),
(134, 81, 88, 81, 1, '1 Maj Zakir', 0, '06/12/2015', 3, 146, NULL),
(135, 81, 88, 82, 3, '1 x Maj Farzad, 1 x Maj Shazzad, 1 x Maj Ripon', 0, '06/12/2015', 4, 147, NULL),
(136, 81, 88, 82, 2, '1 x Co, 1 x Maj Bozlur Rashid', 0, '06/12/2015', 5, 147, NULL),
(137, 81, 88, 82, 1, '1 x Maj zakir', 0, '06/12/2015', 3, 147, NULL),
(139, 81, 88, 83, 2, '1 x Co, 1 x Maj Bozlur Rashid', 0, '06/12/2015', 5, 148, NULL),
(140, 81, 88, 83, 1, '1 xMaj Zakir', 0, '06/12/2015', 3, 148, NULL),
(141, 81, 88, 62, 8, '3 x Maj Farzad, 3 x Maj Shazzad, 2 x Maj Ripon', 0, '06/12/2015', 4, 42, NULL),
(142, 81, 88, 62, 5, '2 x CO, 3 x Maj Bozlur Rashed', 0, '06/12/2015', 5, 42, NULL),
(143, 81, 88, 62, 3, 'Maj Zakir', 0, '06/12/2015', 3, 42, NULL),
(144, 81, 88, 56, 3, '1 x Co, 2 x Maj Bozlur Rashid', 0, '06/12/2015', 5, 36, NULL),
(145, 81, 88, 56, 5, '2 x maj Farzzad, 2 x Shazzad, 1 x Maj Ripon', 0, '06/12/2015', 4, 36, NULL),
(146, 81, 88, 56, 2, '2 x Maj Zakir', 0, '06/12/2015', 3, 36, NULL),
(147, 81, 88, 57, 3, '1 x Co, 2 x Maj Bozlur Rashid', 0, '06/12/2015', 5, 37, NULL),
(148, 81, 88, 57, 2, '2 x Maj Zakir', 0, '06/12/2015', 3, 37, NULL),
(149, 81, 88, 57, 5, '2 x maj Farzzad, 2 x Shazzad, 1 x Maj Ripon', 0, '06/12/2015', 4, 37, NULL),
(150, 81, 83, 60, 2, '1 x Co, 1 x Maj Bozlur Rahman', 0, '06/12/2015', 5, 207, NULL),
(151, 81, 83, 60, 3, '1 x maj Farzzad, 1 x Shazzad, 1 x Maj Ripon', 0, '06/12/2015', 4, 40, NULL),
(152, 81, 83, 60, 1, '1 x Maj Zakir', 0, '06/12/2015', 3, 40, NULL),
(156, 81, 88, 56, 2, 'Cpl Sharif', 0, '03/02/2016', 1, 200, NULL),
(157, 81, 88, 57, 11, 'Lcpl Masum Billal', 0, '03/02/2016', 2, 37, NULL),
(158, 81, 88, 57, 2, 'Cpl Sharif', 0, '03/02/2016', 1, 37, NULL),
(162, 81, 88, 62, 1, 'Capt Rashed Bin Kalam', 0, '02/03/2016', 1, 42, NULL),
(163, 81, 88, 66, 11, 'Sgt Elius', 0, '02/03/2016', 2, 213, NULL),
(164, 81, 88, 66, 1, 'Capt Rashed Bin Kalam', 0, '03/02/2016', 1, 47, NULL),
(165, 81, 83, 78, 11, 'Lcpl Masum Billal', 0, '03/02/2016', 2, 222, NULL),
(166, 81, 83, 78, 1, 'Capt rashed Bin Kalam', 0, '03/02/2016', 1, 222, NULL),
(167, 81, 88, 57, 120, 'Lcpl Masum Bilal', 0, '28/12/2015', 2, 201, NULL),
(170, 81, 88, 66, 11, 'Sgt Elius', 0, '02/03/2016', 2, 211, NULL),
(171, 81, 83, 78, 86, 'Lcpl Masum Bilal', 0, '28/12/2015', 2, 221, NULL),
(172, 81, 88, 79, 86, 'Lcpl Masum Bilal', 0, '28/12/2015', 2, 223, NULL),
(173, 81, 88, 79, 11, 'Lcpl Masum Bilal', 0, '03/02/2016', 2, 223, NULL),
(174, 81, 88, 57, 37, 'Lcpl Iqbal Hossain', 0, '28/12/2015', 3, 203, NULL),
(176, 81, 88, 62, 3, 'Maj Zakir', 0, '06/12/2015', 3, 42, NULL),
(177, 81, 88, 66, 39, 'Lcpl Iqbal Hossain', 0, '28/12/2015', 3, 213, NULL),
(178, 81, 83, 78, 37, 'Lcpl Iqbal Hossain', 0, '28/12/2015', 3, 221, NULL),
(179, 81, 88, 79, 39, 'Lcpl Iqbal Hossain', 0, '28/12/2015', 3, 223, NULL),
(180, 81, 88, 57, 7, 'Cpl sharif', 0, '28/12/2015', 5, 37, NULL),
(181, 81, 88, 62, 5, '2 x CO, 3 x Maj Bozlur Rashed', 0, '06/12/2015', 5, 42, NULL),
(182, 81, 88, 66, 4, 'Cpl sharif', 0, '28/12/2015', 5, 213, NULL),
(183, 81, 83, 78, 5, 'Cpl sharif', 0, '28/12/2015', 5, 221, NULL),
(184, 81, 88, 79, 4, 'Cpl sharif', 0, '28/12/2015', 5, 223, NULL),
(185, 81, 88, 57, 6, 'Cpl sharif', 0, '28/12/2015', 4, 201, NULL),
(187, 81, 88, 62, 8, '3 x Maj Farzad, 3 x Maj Shazzad, 2 x Maj Ripon', 0, '06/12/2015', 4, 42, NULL),
(188, 81, 88, 66, 7, 'Cpl sharif', 0, '28/12/2015', 4, 213, NULL),
(189, 81, 83, 78, 7, 'Cpl sharif', 0, '28/12/2015', 4, 221, NULL),
(190, 81, 88, 79, 7, 'Cpl sharif', 0, '28/12/2015', 4, 223, NULL),
(191, 81, 88, 57, 9, 'Cpl sharif', 0, '28/12/2015', 1, 201, NULL),
(193, 81, 88, 62, 1, 'Capt Rashed Bin Kalam', 0, '02/03/2016', 1, 42, NULL),
(194, 81, 88, 66, 9, 'Cpl sharif', 0, '28/12/2015', 1, 213, NULL),
(195, 81, 83, 78, 9, 'Cpl sharif', 0, '28/12/2015', 1, 221, NULL),
(196, 81, 88, 79, 8, 'Cpl sharif', 0, '28/12/2015', 1, 225, NULL),
(199, 81, 88, 79, 2, 'Cpl Sharif', 0, '03/02/2016', 1, 224, NULL),
(201, 81, 88, 56, 37, 'Lcpl Iqbal Hossain', 0, '28/12/2015', 3, 200, NULL),
(203, 81, 88, 56, 7, 'Cpl Sharif', 0, '28/12/2015', 5, 36, NULL),
(204, 81, 88, 56, 6, 'Cpl Sharif', 0, '28/12/2015', 4, 200, NULL),
(209, 81, 88, 56, 102, 'Lcpl Masum', 0, '28/12/2015', 2, 36, NULL),
(210, 81, 88, 56, 9, 'Cpl Sharif', 0, '28/12/2015', 1, 36, NULL),
(230, 52, 66, 29, 2, '1 x CO, 1 x Maj Bozlur Rashed', 0, '22/03/2016', 5, 254, NULL),
(231, 52, 66, 29, 3, '1 x maj Farzad, 1 x Maj Ahsan, 1 x Maj Ripon', 0, '22/03/2016', 4, 254, NULL),
(232, 52, 66, 29, 1, 'Maj Zakir', 0, '22/03/2016', 3, 254, NULL),
(233, 81, 88, 59, 17, 'Lcpl Iqbal Hossain', 0, '29/12/2015', 3, 39, NULL),
(234, 81, 88, 59, 10, '1st WO (SDO) Rashad', 0, '29/12/2015', 2, 39, NULL),
(235, 81, 83, 60, 1, 'Cpt Rashad bin Kalam', 0, '27/01/2016', 1, 40, NULL),
(236, 81, 83, 60, 1, 'Maj Arif', 0, '03/02/2016', 2, 40, NULL),
(237, 100, 101, 61, 6, '1st Wo (SDO) Rashad', 0, '29/12/2015', 2, 41, NULL),
(238, 100, 101, 61, 9, 'Wo Khalilur Rahman', 0, '29/12/2015', 3, 41, NULL),
(239, 100, 101, 63, 6, '1st Wo (SDO) Rashad', 0, '29/12/2015', 2, 44, NULL),
(240, 100, 101, 63, 6, 'Wo Khalilur Rahman', 0, '29/12/2015', 3, 44, NULL),
(241, 100, 101, 64, 6, '1st Wo (SDO) Rashad', 0, '29/12/2015', 2, 45, NULL),
(242, 100, 101, 64, 6, 'Wo Khlilur Rahman', 0, '29/12/2015', 3, 45, NULL),
(243, 81, 88, 68, 1, 'Capt Rashad Bin Kalam', 0, '27/01/2016', 1, 214, NULL),
(244, 81, 88, 68, 1, 'Maj Arif', 0, '03/02/2016', 2, 214, NULL),
(245, 81, 88, 69, 1, 'Cpt Rashad Bin Kalam', 0, '27/01/2016', 1, 215, NULL),
(246, 81, 88, 69, 1, 'Maj Arif', 0, '03/02/2016', 2, 215, NULL),
(247, 81, 88, 71, 1, 'Maj Arif', 0, '27/01/2016', 2, 216, NULL),
(248, 81, 88, 71, 1, 'Capt Rashad bin Kalam', 0, '03/02/2016', 1, 216, NULL),
(249, 81, 88, 125, 3, '1 x CO, 1 x Maj Bozlur Rashed', 0, '06/12/2015', 5, 249, NULL),
(250, 81, 88, 125, 5, '2 x Maj Farzad, 2 x Maj Shazzad, 1 x Maj Ripon', 0, '06/12/2015', 4, 249, NULL),
(251, 81, 88, 125, 2, 'Maj Zakir ', 0, '06/12/2015', 3, 249, NULL),
(252, 81, 88, 125, 11, 'Lcpl Masum', 0, '03/02/2016', 3, 249, NULL),
(253, 81, 88, 125, 2, 'Cpl Shrif', 0, '03/02/2016', 1, 249, NULL),
(254, 81, 88, 125, 102, 'Sgt Elius Uddin', 0, '28/12/2015', 2, 250, NULL),
(255, 81, 88, 125, 37, 'Lcpl Iqbal Hossain', 0, '28/12/2015', 3, 250, NULL),
(256, 81, 88, 125, 9, 'Cpl Sharif', 0, '28/12/2015', 1, 250, NULL),
(257, 81, 88, 125, 7, 'Cpl Sharif', 0, '28/12/2015', 5, 249, NULL),
(258, 81, 88, 125, 6, 'Cpl Shrif', 0, '28/12/2015', 4, 253, NULL),
(259, 81, 88, 125, 25, 'Lcpl Masum', 0, '26/01/2016', 2, 253, NULL),
(260, 81, 88, 125, 21, 'Lcpl Iqbql', 0, '26/01/2016', 3, 253, NULL),
(261, 81, 88, 72, 1, 'Maj Arif', 0, '27/01/2016', 2, 217, NULL),
(262, 81, 88, 72, 1, 'Capt Rashad Bin Kalam', 0, '02/03/2016', 1, 217, NULL),
(263, 81, 88, 74, 1, 'Maj Arif', 0, '27/01/2016', 2, 218, NULL),
(264, 81, 88, 74, 1, 'Capt Rashad Bin Kalam', 0, '02/03/2016', 1, 218, NULL),
(265, 81, 88, 76, 1, 'Maj Arif', 0, '27/01/2016', 2, 219, NULL),
(266, 81, 88, 76, 1, 'Capt Rashad Bin Kalam', 0, '02/03/2016', 1, 219, NULL),
(267, 81, 88, 84, 1, 'Maj Arif', 0, '27/01/2016', 2, 220, NULL),
(268, 81, 88, 84, 1, 'Capt Rashad Bin Kalam', 0, '02/03/2016', 1, 220, NULL),
(269, 81, 88, 125, 1, 'Abu Noman Mozumder', 0, '11/01/2016', 1, 252, NULL),
(270, 81, 88, 125, 1, 'Maj Arif', 0, '11/01/2016', 2, 252, NULL),
(271, 81, 88, 125, 1, 'Khairul Alom', 0, '03/03/2016', 1, 251, NULL),
(272, 81, 88, 56, 25, 'Sgt Elius Uddin', 0, '27/01/2016', 2, 198, NULL),
(273, 81, 88, 56, 21, 'Lcpl Iqbal Hossain ', 0, '27/01/2016', 3, 198, NULL),
(274, 81, 88, 56, 1, 'Noman Mozumder', 0, '11/01/2016', 1, 36, NULL),
(275, 81, 88, 56, 1, 'Maj Arif', 0, '11/01/2016', 2, 36, NULL),
(276, 81, 88, 57, 25, 'Sgt Elius Uddin', 0, '27/01/2016', 2, 203, NULL),
(277, 81, 88, 57, 5, 'Lcpl Iqbal Hossain', 0, '27/01/2016', 3, 203, NULL),
(278, 81, 88, 57, 1, 'Khairul Alom', 0, '03/03/2016', 1, 202, NULL),
(279, 81, 88, 66, 2, 'Pvt Sha alom', 0, '11/01/2016', 1, 211, NULL),
(280, 81, 88, 66, 11, 'Sgt Elius', 0, '02/03/2016', 2, 211, NULL),
(281, 81, 88, 66, 11, 'Sgt Elius', 0, '02/03/2016', 2, 211, NULL),
(282, 81, 88, 66, 25, 'Lcpl Iqbal Hossain', 0, '27/01/2016', 3, 211, NULL),
(283, 81, 83, 78, 2, '1 x Pvt  Nasar, 1 x  Pvt Sha Alom', 0, '11/01/2016', 1, 221, NULL),
(284, 81, 83, 78, 1, 'Maj Arif', 0, '11/01/2016', 2, 221, NULL),
(285, 81, 83, 78, 21, 'Sgt Elius Uddin', 0, '27/01/2016', 2, 222, NULL),
(286, 81, 83, 78, 24, 'Lcpl Iqbql Hossain', 0, '27/01/2016', 3, 222, NULL),
(287, 81, 88, 62, 11, 'Sgt Elius ', 0, '02/03/2016', 2, 42, NULL),
(288, 81, 88, 62, 102, 'Sgt Elus', 0, '28/12/2015', 2, 209, NULL),
(289, 81, 88, 62, 37, 'Lcpl Iqbal Hossain', 0, '28/12/2015', 3, 209, NULL),
(290, 81, 88, 62, 7, 'Cpl Sharif', 0, '28/12/2015', 5, 209, NULL),
(291, 81, 88, 62, 6, 'Cpl Sharif', 0, '28/12/2015', 4, 208, NULL),
(292, 81, 88, 62, 9, 'Cpl Sharif', 0, '28/12/2015', 1, 210, NULL),
(293, 81, 88, 62, 21, 'Sgt Elus', 0, '27/01/2016', 2, 210, NULL),
(294, 81, 88, 62, 25, 'Lcpl Iqbal Hossain', 0, '27/01/2016', 3, 210, NULL),
(295, 81, 88, 62, 3, '1 x Pvt Abu Numan, 1 x Pvt Sha alom, 1 x Pvt Nasar', 0, '11/01/2016', 1, 210, NULL),
(296, 81, 88, 62, 1, 'Maj Arif', 0, '11/01/2016', 2, 210, NULL),
(297, 81, 88, 62, 1, '1 x khairul', 0, '03/03/2016', 1, 209, NULL),
(298, 81, 83, 58, 0, 'Sgt Elius', 0, '02/03/2016', 2, 38, NULL),
(299, 81, 83, 58, 0, 'Sgt Elius', 0, '02/03/2016', 2, 204, NULL),
(300, 81, 83, 58, 0, 'Maj Bozlur Rashed', 0, '06/12/2015', 5, 204, NULL),
(303, 81, 88, 79, 3, '1 x Pvt Abu Numan, 1 x Pvt Nasar, 1 x Pvt Sha Alom', 0, '11/01/2016', 1, 225, NULL),
(304, 81, 88, 79, 1, 'Maj Arif', 0, '11/01/2016', 2, 225, NULL),
(305, 81, 88, 79, 21, 'Sgt Elius', 0, '27/01/2016', 2, 225, NULL),
(306, 81, 88, 79, 25, 'Lcpl Iqbal Hossain', 0, '27/01/2016', 3, 225, NULL),
(307, 81, 88, 80, 1, 'Maj Arif', 0, '27/01/2016', 2, 226, NULL),
(308, 81, 88, 80, 1, 'Capt Rashed Bin Kalam', 0, '02/03/2016', 1, 226, NULL),
(309, 81, 88, 81, 1, 'Maj Arif', 0, '27/01/2016', 2, 227, NULL),
(310, 81, 88, 81, 1, 'Capt Rashed Bin Kalam', 0, '02/03/2016', 1, 227, NULL),
(311, 81, 88, 82, 1, 'Maj Arif', 0, '27/01/2016', 2, 228, NULL),
(312, 81, 88, 82, 1, 'Capt rashed Bin Kalam', 0, '02/03/2016', 1, 228, NULL),
(313, 81, 88, 117, 1, 'Maj Arif', 0, '27/01/2016', 2, 229, NULL),
(314, 81, 88, 117, 1, 'Capt Rashed Bin Kalam', 0, '02/03/2016', 1, 229, NULL),
(315, 81, 88, 85, 1, 'Maj Arif ', 0, '27/01/2016', 2, 230, NULL),
(316, 81, 88, 85, 1, 'Capt Rashed BIn Kalam', 0, '02/03/2016', 1, 230, NULL),
(317, 81, 88, 86, 2, '1 x Pvt Badsha Mia, 1 x Pvt Shajahan ', 0, '14/02/2016', 1, 231, NULL),
(318, 81, 88, 87, 2, '1 x Pvt Badsha mia, 1 x Pvt Shajahan', 0, '14/02/2016', 1, 232, NULL),
(319, 81, 88, 88, 2, '1 x Pvt Badsha mia, 1 x Pvt Shajahan', 0, '14/02/2016', 1, 233, NULL),
(320, 81, 88, 89, 2, '1 x Pvt Badsha mia, 1 x Pvt Shajahan', 0, '14/02/2016', 1, 234, NULL),
(321, 81, 88, 90, 2, '1 x Pvt Badsha mia, 1 x Pvt Shajahan', 0, '14/02/2016', 1, 235, NULL),
(322, 81, 83, 118, 2, '1 x Pvt Badsha mia, 1 x Pvt Shajahan', 0, '14/02/2016', 1, 236, NULL),
(323, 81, 88, 92, 2, '1 x Pvt Badsha mia, 1 x Pvt Shajahan', 0, '14/02/2016', 1, 237, NULL),
(324, 68, 70, 126, 3, 'Lcpl Iqbal Hossain', 0, '29/03/2016', 3, 263, NULL),
(325, 68, 70, 126, 1, 'Sgt Abu Naeem Md Jubair', 0, '29/03/2016', 2, 263, NULL),
(326, 68, 70, 128, 2, 'Lcpl Iqbal Hossain', 0, '29/03/2016', 3, 261, NULL),
(327, 68, 70, 128, 2, 'Sgt Abu Naeem Md Jubair', 0, '29/03/2016', 2, 261, NULL),
(328, 68, 70, 127, 2, 'Lcpl Iqbal Hossain', 0, '29/03/2016', 3, 262, NULL),
(329, 68, 70, 127, 2, 'Sgt Abu Naeem Md Jubair', 0, '29/03/2016', 2, 262, NULL),
(330, 68, 70, 129, 2, 'Lcpl Iqbal Hossain', 0, '29/03/2016', 3, 260, NULL),
(331, 68, 70, 129, 2, 'Sgt Abu Naeem Md Jubair', 0, '29/03/2016', 2, 260, NULL),
(332, 68, 103, 130, 3, 'Sgt Abu Naeem Md Jubair', 0, '29/03/2016', 2, 259, NULL),
(333, 68, 103, 130, 2, 'Lcpl Iqbal Hossain', 0, '29/03/2016', 3, 259, NULL),
(334, 68, 70, 131, 1, 'Sgt Abu Naeem Md Jubair', 0, '29/03/2016', 2, 258, NULL),
(335, 68, 70, 132, 2, 'Lcpl Iqbal Hossain', 0, '29/03/2016', 2, 270, NULL),
(336, 68, 70, 132, 2, 'Sgt abu Neam jubair', 0, '29/03/2016', 3, 270, NULL),
(337, 68, 102, 137, 1, 'Sgt Abu Naeem Md Jubair', 0, '29/03/2016', 2, 264, NULL),
(338, 68, 102, 137, 1, 'Lcpl Iqbal Hossain', 0, '29/03/2016', 3, 264, NULL),
(339, 81, 88, 59, 8, 'Lcpl Iqbal Hossain', 0, '05/04/2016', 3, 271, NULL),
(340, 100, 101, 61, 8, 'Lcpl Iqbal Hoosan', 0, '05/04/2016', 3, 276, NULL),
(341, 100, 101, 146, 8, 'Lcpl Iqbal Hosain', 0, '05/04/2016', 3, 272, NULL),
(342, 100, 101, 64, 8, 'Lcpl Iqbal Hossain', 0, '05/04/2016', 3, 273, NULL),
(343, 52, 99, 134, 0, 'Sgt MIzan', 0, '05/04/2016', 4, 256, NULL),
(344, 52, 99, 134, 0, 'Sgt Rokonuzzaman', 0, '05/04/2016', 5, 256, NULL),
(345, 81, 88, 125, 4, 'Lcpl Iqbal', 0, '05/04/2016', 3, 253, NULL),
(346, 81, 88, 125, 1, 'Lcpl Harun or Rashid', 0, '05/04/2016', 5, 253, NULL),
(347, 81, 88, 125, 5, 'Sgt Abu Naeem Md Jubair', 0, '05/04/2016', 2, 253, NULL),
(348, 81, 88, 56, 4, 'Lcpl Iqbal', 0, '05/04/2016', 3, 200, NULL),
(349, 81, 88, 56, 1, 'Lcpl Harun or Roshid', 0, '05/04/2016', 5, 200, NULL),
(350, 81, 88, 56, 5, 'Sgt Abu Naeem Md Jubair', 0, '05/04/2016', 2, 200, NULL),
(351, 81, 88, 57, 4, 'Lcpl Iqbal', 0, '05/04/2016', 3, 201, NULL),
(352, 68, 70, 144, 1, 'Lcpl Iqbal Hossan', 0, '05/04/2016', 3, 274, NULL),
(353, 81, 88, 62, 1, 'Lcpl Harun or Rashid', 0, '05/04/2016', 5, 209, NULL),
(354, 81, 88, 62, 4, 'Lcpl Iqbal Hossan', 0, '05/04/2016', 3, 210, NULL),
(355, 81, 88, 62, 5, 'Sgt Abu Naeem Md Jubair', 0, '05/04/2016', 2, 210, NULL),
(356, 81, 88, 66, 1, 'Lcpl Harun or Rashid', 0, '05/04/2016', 5, 211, NULL),
(357, 81, 88, 66, 4, 'Lcpl Iqbal Hossain', 0, '05/04/2016', 3, 211, NULL),
(358, 81, 88, 66, 5, 'Sgt Abu Naeem Md Jubair', 0, '05/04/2016', 2, 211, NULL),
(359, 81, 83, 78, 1, 'Lcpl Harun Or Rashid', 0, '05/04/2016', 5, 221, NULL),
(360, 81, 83, 78, 4, 'Lcpl Iqbal Hossain', 0, '05/04/2016', 3, 222, NULL),
(361, 81, 83, 78, 5, 'Sgt Abu naeem jobaer ', 0, '05/04/2016', 2, 222, NULL),
(362, 81, 88, 79, 1, 'Lcpl Harun Or rashid', 0, '05/04/2016', 5, 225, NULL),
(363, 81, 88, 79, 4, 'Lcpl Iqbal Hossain', 0, '05/04/2016', 3, 225, NULL),
(364, 81, 88, 79, 5, 'Sgt Abu Naeem Md Jubair', 0, '05/04/2016', 2, 225, NULL),
(365, 81, 88, 57, 5, 'Sgt Abu Naeem Md Jubair', 0, '05/04/2016', 2, 201, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `im_gallery`
--

CREATE TABLE IF NOT EXISTS `im_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `im_gallery`
--

INSERT INTO `im_gallery` (`id`, `item_id`, `image_path`) VALUES
(1, 117, '20160302145690902096009687.jpg'),
(2, 118, '20160302145690902035130750.jpg'),
(3, 119, '20160302145691456270235744.jpg'),
(4, 9, '20160303145697752158057518.jpg'),
(5, 9, '20160303145697752158057518.jpg'),
(6, 9, '20160303145697752158057518.jpg'),
(7, 13, '20160303145697729775930094.jpg'),
(8, 15, '20160303145697761821882547.jpg'),
(9, 120, ''),
(10, 121, '20160303145697804535831875.jpg'),
(11, 122, '20160303145697804535831875.jpg'),
(12, 123, '2016030314569780461303022.jpg'),
(13, 124, ''),
(14, 125, '2016030314569786156854098.jpg'),
(15, 126, '2016030314569786156854098.jpg'),
(16, 127, '20160303145697861567263587.jpg'),
(17, 128, '20160303145697925284986792.jpg'),
(18, 131, '20160303145697925282246310.jpg'),
(19, 264, '20160327145907580285044711.JPG'),
(20, 277, '20160407146001619732533542.jpg'),
(21, 278, '20160407146003677982520663.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `im_item_gallery`
--

CREATE TABLE IF NOT EXISTS `im_item_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `image_path` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `im_item_gallery`
--

INSERT INTO `im_item_gallery` (`id`, `item_id`, `image_path`) VALUES
(1, 4, '20160407146003190253747127.jpg'),
(2, 12, '20160407146003198485831190.png'),
(3, 5, '2016041014602608734512952.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `im_stock`
--

CREATE TABLE IF NOT EXISTS `im_stock` (
  `fld_id` int(11) NOT NULL AUTO_INCREMENT,
  `fld_store_id` int(11) NOT NULL,
  `fld_parent_id` int(11) NOT NULL,
  `fld_category_id` int(11) NOT NULL,
  `fld_item_id` int(11) NOT NULL,
  `fld_cre_by` int(4) NOT NULL,
  `fld_cre_date` date NOT NULL,
  `fld_upd_by` int(4) NOT NULL,
  `fld_upd_date` date DEFAULT NULL,
  `fld_description` text NOT NULL,
  `fld_last_receive_date` varchar(20) NOT NULL,
  `fld_quantity` int(11) NOT NULL,
  `fld_history_quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`fld_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=279 ;

--
-- Dumping data for table `im_stock`
--

INSERT INTO `im_stock` (`fld_id`, `fld_store_id`, `fld_parent_id`, `fld_category_id`, `fld_item_id`, `fld_cre_by`, `fld_cre_date`, `fld_upd_by`, `fld_upd_date`, `fld_description`, `fld_last_receive_date`, `fld_quantity`, `fld_history_quantity`) VALUES
(6, 218, 76, 77, 54, 1, '2016-02-29', 0, '2016-03-06', 'No-28590, Mitsubishi Engine number-6372,Chacge number-736577 ', '01/02/2016', 1, 1),
(7, 218, 76, 77, 54, 1, '2016-02-29', 0, '2016-03-01', 'No-74778 SUZUKI Grand Vitara(Blue) ', '21/02/2016', 1, 1),
(8, 218, 76, 77, 54, 1, '2016-02-29', 0, '2016-03-01', 'No-33281 SUZUKI Grand Vitara (White)', '21/02/2016', 1, 1),
(9, 218, 52, 99, 4, 1, '2016-02-29', 0, '2016-04-05', 'HP Pro book core i-7, RAM-8 GB, HDD - 250 GB ', '30/11/2015', 4, 4),
(11, 218, 52, 99, 23, 1, '2016-02-29', 0, '2016-04-05', 'KYOCERA Task ALFA 55011 (with all accessories)', '30/11/2015', 2, 2),
(12, 218, 52, 66, 24, 1, '2016-02-29', 0, '2016-03-24', 'commercial paper sadder ', '30/11/2015', 2, 2),
(13, 218, 52, 53, 25, 1, '2016-02-29', 0, '2016-03-03', 'CASIO 12 digit', '30/11/2015', 10, 10),
(14, 218, 52, 66, 26, 1, '2016-02-29', 0, '2016-03-01', 'items 8', '30/11/2015', 12, 12),
(15, 218, 52, 66, 112, 1, '2016-02-29', 0, '2016-03-06', 'punch type', '30/11/2015', 8, 8),
(16, 218, 52, 53, 28, 1, '2016-02-29', 0, '2016-03-02', '24/6 inch', '30/11/2015', 8, 8),
(17, 218, 52, 66, 29, 1, '2016-02-29', 0, '2016-03-01', ' TOSIBA 16 GB', '30/11/2015', 2, 2),
(18, 218, 52, 99, 31, 1, '2016-02-29', 0, '2016-04-05', 'For laptop', '30/11/2015', 4, 4),
(19, 218, 52, 53, 32, 1, '2016-02-29', 0, '2016-03-01', '4 plug ', '30/11/2015', 7, 7),
(21, 218, 52, 99, 22, 1, '2016-02-29', 0, '2016-04-05', 'Intel(R) core(TM) i5, RAM - 8.00, HDD- 500 GB (All Accessories)  ', '30/11/2015', 5, 5),
(22, 218, 52, 99, 35, 1, '2016-02-29', 0, '2016-04-05', 'HP-1740', '09/12/2015', 1, 1),
(23, 218, 52, 54, 46, 1, '2016-02-29', 0, '2016-03-01', 'Official ', '19/01/2016', 9, 9),
(24, 218, 52, 54, 47, 1, '2016-02-29', 0, '2016-03-01', 'For office', '19/01/2016', 8, 8),
(25, 218, 52, 54, 48, 1, '2016-02-29', 0, '2016-03-01', 'Single ', '19/01/2016', 3, 3),
(28, 218, 52, 54, 49, 1, '2016-03-01', 0, '2016-03-01', 'Easy & High', '19/01/2016', 7, 7),
(29, 218, 52, 54, 50, 1, '2016-03-01', 0, '2016-03-03', 'For office (Logistic)', '25/01/2016', 2, 2),
(30, 218, 52, 54, 51, 1, '2016-03-01', 0, '2016-03-03', 'For office (Logistic)', '25/01/2016', 2, 2),
(32, 218, 68, 69, 53, 1, '2016-03-01', 0, '2016-04-05', 'For Field work', '14/02/2016', 1, 1),
(33, 218, 52, 53, 34, 1, '2016-03-01', 0, '2016-03-01', 'AVAYA', '30/11/2015', 10, 10),
(36, 218, 81, 88, 56, 1, '2016-03-01', 0, '2016-03-06', ' Type kuwait', '30/11/2015', 30, 30),
(37, 218, 81, 88, 57, 1, '2016-03-01', 0, '2016-03-06', 'Type kuwait ', '30/11/2015', 30, 30),
(38, 218, 81, 83, 58, 1, '2016-03-01', 0, '2016-04-07', 'Type Kuwait ', '30/11/2015', 30, 30),
(39, 218, 81, 88, 59, 1, '2016-03-01', 0, '2016-03-01', 'Type Kuwait ', '30/11/2015', 30, 30),
(40, 218, 81, 83, 60, 1, '2016-03-01', 0, '2016-03-13', 'Type Kuwait ', '30/11/2015', 30, 30),
(41, 218, 100, 101, 61, 1, '2016-03-01', 0, '2016-04-07', 'Type Kuwait ', '30/11/2015', 15, 15),
(42, 218, 81, 88, 62, 1, '2016-03-01', 0, '2016-03-23', 'Type of Kuwait  ', '30/11/2015', 30, 30),
(44, 218, 100, 101, 63, 1, '2016-03-01', 0, '2016-04-05', 'Hand gloves', '30/11/2015', 15, 15),
(45, 218, 100, 101, 64, 1, '2016-03-01', 0, '2016-04-05', 'Sun glass', '30/11/2015', 15, 15),
(46, 218, 81, 88, 65, 1, '2016-03-01', 0, '2016-03-01', 'For officer''s only', '02/12/2015', 6, 6),
(47, 218, 81, 88, 66, 1, '2016-03-01', 0, '0000-00-00', 'Belt lylon', '02/12/2015', 6, 6),
(48, 218, 81, 88, 67, 1, '2016-03-01', 0, '0000-00-00', 'For officer''s only', '02/12/2015', 6, 6),
(49, 218, 81, 88, 68, 1, '2016-03-01', 0, '0000-00-00', 'For officer''s only', '02/12/2015', 6, 6),
(132, 218, 81, 88, 69, 1, '2016-03-03', 0, '0000-00-00', 'For officer''s only', '02/12/2015', 6, 6),
(133, 218, 81, 88, 70, 1, '2016-03-03', 0, '2016-03-06', 'For officer''s only', '02/12/2015', 5, 5),
(134, 218, 81, 88, 71, 1, '2016-03-03', 0, '2016-03-06', 'For officer''s only', '02/12/2015', 6, 6),
(135, 218, 81, 88, 72, 1, '2016-03-03', 0, '0000-00-00', 'For officer''s only', '02/12/2015', 6, 6),
(136, 218, 81, 88, 73, 1, '2016-03-03', 0, '0000-00-00', 'For officer''s only', '02/12/2015', 6, 6),
(137, 218, 81, 88, 74, 1, '2016-03-03', 0, '0000-00-00', 'For officer''s only', '02/12/2015', 6, 6),
(138, 218, 81, 88, 76, 1, '2016-03-03', 0, '0000-00-00', 'For officer''s only', '02/12/2015', 6, 6),
(139, 218, 81, 83, 58, 1, '2016-03-03', 0, '2016-04-07', 'For officer''s only', '02/12/2015', 6, 6),
(140, 218, 81, 88, 77, 1, '2016-03-03', 0, '0000-00-00', 'For officer''s only', '02/12/2015', 6, 6),
(141, 218, 81, 88, 84, 1, '2016-03-03', 0, '2016-03-20', 'For officer''s only', '02/12/2015', 8, 8),
(142, 218, 81, 83, 78, 1, '2016-03-03', 0, '2016-03-13', 'For officer''s only', '02/12/2015', 8, 6),
(143, 218, 81, 83, 91, 1, '2016-03-03', 0, '2016-03-13', 'For officer''s only', '02/12/2015', 6, 6),
(144, 218, 81, 88, 79, 1, '2016-03-03', 0, '0000-00-00', 'For officer''s only', '02/12/2015', 6, 6),
(145, 218, 81, 88, 80, 1, '2016-03-03', 0, '0000-00-00', 'For officer''s only', '02/12/2015', 7, 7),
(146, 218, 81, 88, 81, 1, '2016-03-03', 0, '0000-00-00', 'For officer''s only', '02/12/2015', 6, 6),
(147, 218, 81, 88, 82, 1, '2016-03-03', 0, '0000-00-00', 'For officer''s only', '02/12/2015', 6, 6),
(150, 218, 68, 70, 5, 1, '2016-03-03', 0, '0000-00-00', 'Adjustable punch Machine', '18/02/2016', 1, 1),
(151, 218, 68, 102, 6, 1, '2016-03-03', 0, '2016-04-05', 'Set of 3 pieces', '18/02/2016', 1, 1),
(152, 218, 68, 69, 7, 1, '2016-03-03', 0, '2016-04-05', 'Packed ', '18/02/2016', 1, 1),
(153, 218, 68, 70, 8, 1, '2016-03-03', 0, '0000-00-00', 'Electric ', '18/02/2016', 1, 1),
(154, 218, 68, 70, 9, 1, '2016-03-03', 0, '0000-00-00', 'Size 6 to 14 pcs ', '18/02/2016', 1, 1),
(155, 218, 52, 66, 10, 1, '2016-03-03', 0, '0000-00-00', 'Office use only ', '18/02/2016', 1, 1),
(156, 218, 68, 70, 11, 1, '2016-03-03', 0, '0000-00-00', 'Cutting players ', '18/02/2016', 1, 1),
(157, 218, 68, 70, 12, 1, '2016-03-03', 0, '0000-00-00', 'Star & flat type ', '18/02/2016', 1, 1),
(158, 218, 68, 102, 13, 1, '2016-03-03', 0, '2016-04-05', '1/2,1 pound ', '18/02/2016', 2, 2),
(159, 218, 68, 70, 14, 1, '2016-03-03', 0, '0000-00-00', '95mm', '18/02/2016', 10, 10),
(160, 218, 68, 70, 104, 1, '2016-03-03', 0, '0000-00-00', 'Tape', '18/02/2016', 5, 5),
(161, 218, 68, 70, 16, 1, '2016-03-03', 0, '0000-00-00', 'Base boll', '18/02/2016', 6, 6),
(162, 218, 68, 70, 17, 1, '2016-03-03', 0, '0000-00-00', 'Packet ', '18/02/2016', 1, 1),
(163, 218, 68, 70, 18, 1, '2016-03-03', 0, '0000-00-00', 'Set ', '18/02/2016', 1, 1),
(164, 218, 81, 89, 40, 1, '2016-03-03', 0, '0000-00-00', 'Steel type', '27/01/2016', 105, 105),
(165, 218, 81, 89, 43, 1, '2016-03-03', 0, '0000-00-00', 'With cover', '27/01/2016', 105, 105),
(166, 218, 81, 89, 44, 1, '2016-03-03', 0, '0000-00-00', 'Foam type', '27/01/2016', 105, 105),
(167, 218, 81, 89, 45, 1, '2016-03-03', 0, '0000-00-00', 'Other cooler ', '27/01/2016', 105, 105),
(168, 218, 81, 89, 115, 1, '2016-03-03', 0, '0000-00-00', 'Cooler Khaki', '27/01/2016', 105, 105),
(169, 218, 81, 89, 41, 1, '2016-03-03', 0, '0000-00-00', 'Steel type', '27/01/2016', 105, 105),
(170, 218, 81, 89, 41, 1, '2016-03-03', 0, '2016-03-03', 'Steel type (Camp Logistic)', '25/01/2016', 70, 70),
(171, 218, 81, 89, 40, 1, '2016-03-03', 0, '0000-00-00', 'Double type  (Logistic', '25/01/2016', 25, 25),
(172, 218, 81, 89, 44, 1, '2016-03-03', 0, '2016-03-03', 'Foam Type (Logistic)', '25/01/2016', 70, 70),
(173, 218, 81, 89, 45, 1, '2016-03-03', 0, '0000-00-00', 'with cover (Logistic)', '25/01/2016', 70, 70),
(174, 218, 81, 89, 43, 1, '2016-03-03', 0, '0000-00-00', 'Logistic', '25/01/2016', 70, 70),
(175, 218, 81, 89, 115, 1, '2016-03-03', 0, '0000-00-00', 'Khaki type Logistic', '25/01/2016', 140, 140),
(176, 218, 52, 54, 49, 1, '2016-03-03', 0, '0000-00-00', 'For CO', '25/01/2016', 1, 1),
(177, 218, 81, 89, 41, 1, '2016-03-03', 0, '0000-00-00', 'Steel type maintenance company side room  ', '26/01/2016', 11, 11),
(178, 218, 81, 89, 40, 1, '2016-03-03', 0, '0000-00-00', 'Steel type Maintenance company side room ', '26/01/2016', 7, 7),
(179, 218, 81, 89, 44, 1, '2016-03-03', 0, '0000-00-00', 'Foam type (Steel type Maintenance company side room)', '26/01/2016', 11, 11),
(180, 218, 81, 89, 115, 1, '2016-03-03', 0, '0000-00-00', 'cooler khaki (Steel type Maintenance company side room)', '26/01/2016', 11, 11),
(181, 218, 81, 89, 43, 1, '2016-03-03', 0, '0000-00-00', '(Steel type Maintenance company side room)', '26/01/2016', 7, 7),
(182, 218, 81, 89, 45, 1, '2016-03-03', 0, '0000-00-00', '(Steel type Maintenance company side room)', '26/01/2016', 7, 7),
(183, 218, 52, 99, 21, 1, '2016-03-06', 0, '2016-04-05', 'Laser Jet Pro 400M401A.Serial No-PHKBC16911,PHKBB16355,PHKBB16411,', '30/12/2015', 4, 4),
(184, 218, 52, 99, 21, 1, '2016-03-06', 0, '2016-04-05', 'Samsung ', '04/01/2016', 1, 1),
(185, 218, 52, 99, 116, 1, '2016-03-06', 0, '2016-04-05', 'Printer Use ', '30/11/2015', 4, 4),
(186, 218, 81, 89, 40, 1, '2016-03-06', 0, '0000-00-00', 'Single ', '19/01/2016', 20, 20),
(187, 218, 81, 89, 41, 1, '2016-03-06', 0, '0000-00-00', 'Steel type', '19/01/2016', 60, 60),
(188, 218, 81, 89, 115, 1, '2016-03-06', 0, '0000-00-00', 'Virginia Camp( Askary Collar )', '31/01/2016', 60, 60),
(189, 218, 81, 89, 115, 1, '2016-03-06', 0, '0000-00-00', '1st Issue', '19/01/2016', 60, 60),
(190, 218, 81, 89, 43, 1, '2016-03-06', 0, '0000-00-00', 'with cover', '19/01/2016', 60, 60),
(191, 218, 81, 89, 44, 1, '2016-03-06', 0, '0000-00-00', '1st Issue ', '19/01/2016', 60, 60),
(192, 218, 81, 89, 45, 1, '2016-03-06', 0, '0000-00-00', '1st Issue', '19/01/2016', 60, 60),
(193, 218, 68, 102, 52, 1, '2016-03-06', 0, '2016-04-05', 'set of 8 pieces ', '14/02/2016', 1, 1),
(198, 218, 81, 88, 56, 1, '2016-03-06', 0, '0000-00-00', 'Kuwaiti Cooler ', '14/12/2015', 148, 148),
(199, 218, 81, 88, 56, 1, '2016-03-06', 0, '0000-00-00', 'Kuwaiti Cooler', '06/01/2016', 1, 1),
(200, 218, 81, 88, 56, 1, '2016-03-06', 0, '2016-03-20', 'Kuwaiti Cooler', '25/01/2016', 72, 72),
(201, 218, 81, 88, 57, 1, '2016-03-06', 0, '0000-00-00', 'Kuwaiti Cooler', '14/12/2015', 148, 148),
(202, 218, 81, 88, 57, 1, '2016-03-06', 0, '0000-00-00', 'Kuwaiti Cooler', '06/01/2016', 1, 1),
(203, 218, 81, 88, 57, 1, '2016-03-06', 0, '0000-00-00', 'Kuwaiti Cooler', '25/01/2016', 72, 72),
(204, 218, 81, 83, 58, 1, '2016-03-06', 0, '2016-04-07', 'Kuwaiti Cooler', '14/12/2015', 148, 148),
(205, 218, 81, 83, 58, 1, '2016-03-06', 0, '2016-04-07', 'Kuwaiti Cooler', '06/01/2016', 1, 1),
(206, 218, 81, 83, 58, 1, '2016-03-06', 0, '2016-04-07', 'Kuwaiti Cooler', '25/01/2016', 72, 72),
(207, 218, 81, 83, 60, 1, '2016-03-06', 0, '0000-00-00', 'Officer''s Only', '25/01/2016', 2, 2),
(208, 218, 81, 88, 62, 1, '2016-03-06', 0, '2016-03-23', 'Kuwaiti ', '12/02/2016', 6, 6),
(209, 218, 81, 88, 62, 1, '2016-03-06', 0, '2016-03-23', 'Kuwaiti ', '14/12/2015', 148, 148),
(210, 218, 81, 88, 62, 1, '2016-03-06', 0, '2016-03-23', 'Kuwaiti ', '25/01/2016', 72, 72),
(211, 218, 81, 88, 66, 1, '2016-03-06', 0, '0000-00-00', 'With Kuwaiti tag', '14/12/2015', 148, 148),
(212, 218, 81, 88, 66, 1, '2016-03-06', 0, '0000-00-00', 'With Kuwaiti tag', '06/01/2016', 1, 1),
(213, 218, 81, 88, 66, 1, '2016-03-06', 0, '0000-00-00', 'With Kuwaiti tag', '26/01/2016', 70, 70),
(214, 218, 81, 88, 68, 1, '2016-03-06', 0, '0000-00-00', 'kuwaiti', '25/01/2016', 2, 2),
(215, 218, 81, 88, 69, 1, '2016-03-06', 0, '0000-00-00', 'kuwaiti', '25/01/2016', 2, 2),
(216, 218, 81, 88, 71, 1, '2016-03-06', 0, '0000-00-00', 'kuwaiti', '25/01/2016', 2, 2),
(217, 218, 81, 88, 72, 1, '2016-03-06', 0, '0000-00-00', 'kuwaiti', '25/01/2016', 2, 2),
(218, 218, 81, 88, 74, 1, '2016-03-06', 0, '0000-00-00', 'kuwaiti', '25/01/2016', 2, 2),
(219, 218, 81, 88, 76, 1, '2016-03-06', 0, '0000-00-00', 'kuwaiti', '25/01/2016', 2, 2),
(220, 218, 81, 88, 84, 1, '2016-03-06', 0, '0000-00-00', 'kuwaiti', '25/01/2016', 2, 2),
(221, 218, 81, 83, 78, 1, '2016-03-06', 0, '2016-03-13', 'kuwaiti', '14/12/2015', 148, 148),
(222, 218, 81, 83, 78, 1, '2016-03-06', 0, '2016-03-13', 'kuwaiti', '25/01/2016', 70, 70),
(223, 218, 81, 88, 79, 1, '2016-03-06', 0, '0000-00-00', 'kuwaiti', '14/01/2016', 148, 148),
(224, 218, 81, 88, 79, 1, '2016-03-06', 0, '0000-00-00', 'kuwaiti', '06/01/2016', 1, 1),
(225, 218, 81, 88, 79, 1, '2016-03-06', 0, '0000-00-00', 'kuwaiti', '25/01/2016', 72, 72),
(226, 218, 81, 88, 80, 1, '2016-03-06', 0, '0000-00-00', 'kuwaiti', '25/01/2016', 2, 2),
(227, 218, 81, 88, 81, 1, '2016-03-06', 0, '0000-00-00', 'kuwaiti', '25/01/2016', 2, 2),
(228, 218, 81, 88, 82, 1, '2016-03-06', 0, '0000-00-00', 'kuwaiti', '25/01/2016', 2, 2),
(229, 218, 81, 88, 117, 1, '2016-03-07', 0, '0000-00-00', 'Officer''s Only', '25/01/2016', 2, 2),
(230, 218, 81, 88, 85, 1, '2016-03-07', 0, '0000-00-00', 'Officer''s Only ', '25/01/2016', 2, 2),
(231, 218, 81, 88, 86, 1, '2016-03-07', 0, '2016-03-07', 'Mess Waiter', '08/02/2016', 4, 4),
(232, 218, 81, 88, 87, 1, '2016-03-07', 0, '2016-03-07', 'Mess Waiter', '08/02/2016', 4, 4),
(233, 218, 81, 88, 88, 1, '2016-03-07', 0, '0000-00-00', 'Mess Waiter', '08/02/2016', 4, 4),
(234, 218, 81, 88, 89, 1, '2016-03-07', 0, '0000-00-00', 'Mess waiter  Only', '08/02/2016', 4, 4),
(235, 218, 81, 88, 90, 1, '2016-03-07', 0, '0000-00-00', 'Mess waiter  Only', '08/02/2016', 4, 4),
(236, 218, 81, 83, 118, 1, '2016-03-07', 0, '2016-03-13', 'Mess waiter  Only', '08/02/2016', 4, 4),
(237, 218, 81, 88, 92, 1, '2016-03-07', 0, '0000-00-00', 'Mess waiter  Only', '08/02/2016', 6, 6),
(238, 218, 81, 88, 93, 1, '2016-03-07', 0, '0000-00-00', 'Use for Cook', '08/02/2016', 4, 4),
(239, 218, 81, 88, 94, 1, '2016-03-07', 0, '0000-00-00', 'Cook  Use Only', '08/02/2016', 4, 4),
(240, 218, 81, 88, 95, 1, '2016-03-07', 0, '0000-00-00', 'Cook  Use Only', '08/02/2016', 4, 4),
(241, 218, 52, 53, 119, 1, '2016-03-08', 0, '0000-00-00', 'Panasonic  Model:DMC-FZ70', '09/03/2016', 2, 2),
(242, 218, 52, 99, 120, 1, '2016-03-09', 0, '2016-04-05', 'Made in china ', '09/02/2016', 1, 1),
(243, 218, 52, 53, 32, 1, '2016-03-15', 0, NULL, '4 plug ', '09/03/2016', 4, 4),
(244, 218, 52, 99, 121, 1, '2016-03-16', 0, '2016-04-05', 'Monitor (TV LED Orca 28") ,ser No: IKF 120434C-0080 & IKF120434C-0170', '16/03/2016', 2, 2),
(245, 218, 52, 99, 122, 1, '2016-03-16', 0, '2016-04-05', 'Ecosys Kyocera Ser No: LS95Y00401 & LS5Y00740', '16/03/2016', 2, 2),
(246, 218, 52, 53, 34, 1, '2016-03-16', 0, '2016-03-16', 'Panasonic . 2 x small size 3 X big Size.Ser No: 3 x KXT7730X & 2 X KXT7705X', '16/03/2016', 5, 5),
(247, 218, 52, 53, 124, 1, '2016-03-16', 0, NULL, 'Panasonic .Ser NO: KXTEX824', '16/03/2016', 1, 1),
(248, 218, 68, 70, 19, 1, '2016-03-16', 0, NULL, '6 Pic ', '18/02/2016', 1, 1),
(249, 218, 81, 88, 125, 1, '2016-03-22', 0, '2016-03-22', 'Service Colour ', '30/11/2015', 30, 30),
(250, 218, 81, 88, 125, 1, '2016-03-22', 0, '2016-03-22', 'Service colour ', '14/02/2016', 148, 148),
(251, 218, 81, 88, 125, 1, '2016-03-22', 0, '2016-03-22', 'Service colour  ', '06/01/2016', 1, 1),
(252, 218, 81, 88, 125, 1, '2016-03-22', 0, '2016-03-22', 'Service colour', '25/01/2016', 1, 2),
(253, 218, 81, 88, 125, 1, '2016-03-22', 0, '2016-03-22', 'Service colour', '25/01/2016', 72, 70),
(254, 218, 52, 66, 29, 1, '2016-03-22', 0, NULL, 'TOSIBA 16 GB', '22/03/2016', 7, 7),
(255, 218, 52, 99, 135, 1, '2016-03-27', 0, '2016-04-05', 'D-Link', '24/03/2016', 1, 1),
(256, 218, 52, 99, 134, 1, '2016-03-27', 0, '2016-04-05', 'Quick', '24/03/2016', 9, 9),
(257, 218, 68, 69, 133, 1, '2016-03-27', 0, '2016-03-27', 'Model: N5900B,235mm,2000 Watt,Made in Chaina', '24/03/2016', 4, 4),
(258, 218, 68, 70, 131, 1, '2016-03-27', 0, '2016-04-05', 'Eye Shelled-1, Wire brush-1, Wheel-2, Handle-2, Welding holder & earthing cable-1', '24/2/2016', 1, 1),
(259, 218, 68, 103, 130, 1, '2016-03-27', 0, '2016-04-05', ' (For Carpenter)', '24/03/2016', 5, 5),
(260, 218, 68, 70, 129, 1, '2016-03-27', 0, '2016-04-05', 'Model: HP1630, 710 Watt,made in Romania\r\nBit key -4', '24/03/2016', 4, 4),
(261, 218, 68, 70, 128, 1, '2016-03-27', 0, '2016-04-05', 'Model:9553HN(100MM Dia),710 Watt,\r\nDisc-1, Disc cover-1, Handle -1, Disc Key', '24/03/2016', 4, 4),
(262, 218, 68, 70, 127, 1, '2016-03-27', 0, '2016-04-05', 'Model: GSR 1800-LI professional, Made in Malaysia.\r\nRechargeable Battery 18 volt -8,\r\nCharger -4', '24/03/2016', 4, 4),
(263, 218, 68, 70, 126, 1, '2016-03-27', 0, '2016-04-05', '(Gasoline Botong )4.5 KVA\r\n Generator Cable 100 meter', '24/03/2016', 2, 2),
(264, 218, 68, 102, 137, 1, '2016-03-27', 0, '2016-04-05', 'One tool box contains following items:\r\nSpeed level salon - 02,\r\nWater pump pliers 12 " (draft man) - 02,\r\nSteel Tape 8 meter - 02,\r\nCombination wrench (set of 7 pcs) - 02,\r\nHack saw frame with blade - 02,\r\nBall pin Hammer - 02,\r\nNose pliers - 02,\r\nHeavy duty pipe wrench 12" - 02,\r\nScrew driver (set of 6)  - 02,\r\nLocking pliers - 02,\r\nCombination pliers 8" - 02,\r\nCutting pliers 6" - 02,\r\nAdjustable wrench 10'''' - 02,\r\nSocket wrench (Set 26 pcs) - 02,\r\n5" Workshop Srech (vice) - 02\r\nHammer drill (makita) HP-1630 with Bit key lock - o2', '24/03/2016', 2, 2),
(265, 218, 68, 69, 138, 1, '2016-03-27', 0, '2016-03-29', 'One tool box contains following items:\r\nMeasuring Tape 100 Mtr( sunlon) - 03,\r\nChalk line red ( with chalk) - 03,\r\nMeasuring Tape 8  meter - 03,\r\nMeasuring Tape 30  meter - 03,\r\nMagmatic plum Bob-03,\r\nCombination square 12"- 03,\r\nAngular - 03,\r\nSpeed level (Sola)-03,\r\nCombination pliers 8" - 03,\r\nCombination pliers 9"- 03,\r\nSteel scale 12"- 03,\r\nHand Saw - 03,\r\nSlotted Screw driver (Set of 6)- 03,\r\nClaw hammer 12'''' - 03,\r\nClaw hammer 16 oz - 03,\r\nGorilla Bar 18'''' - 03,\r\nCompound meter Saw - 03', '24/03/2016', 3, 3),
(266, 218, 68, 103, 139, 1, '2016-03-28', 0, '2016-04-05', 'One tool box contains following items:\r\nCombination pliers 8"- 02,\r\nCombination pliers  9" -02,\r\nAnti Cutter - 02,\r\nCombination square 12" - 02,\r\nClaw Hammer - 02,\r\nRubber Hammer - 02,\r\nSpanner (Set of 7) - 02,\r\nHand Saw -02,\r\nHack Saw with frame - 02 ,\r\nWilko - 02,\r\nCombination Wrench  (Set of 6)- 02,\r\nStanley  -02,\r\nWooden Handle - 02,\r\nFarmer chisel  (Set of 4) -02,\r\nDrill bit (Set of 16) - 02,\r\nWooden fixing vice  (1 x red, 1 x black) - 02,\r\nMutt um-02, \r\nTape 8 Meter -02,\r\nCombination Square -02, \r\nPlastic Vice - 02,\r\nWorkshop Vice -02,\r\nHand drill manual -02,\r\n6'''' File &#40;Set of 05&#41; - 02,\r\nSanding paper fixer -02,\r\nCompound meter saw  - 02\r\n', '24/03/2016', 2, 2),
(267, 218, 68, 70, 141, 1, '2016-03-28', 0, '2016-04-05', 'One tool box contains following items:\r\nDigital clamp meter - 02,\r\nVoltage Tester - 02,\r\nLock pliers - 02,\r\nCrimping tools 0.5 - 2mm -02,\r\nSocket wrench (set of 17 pcs) -02,\r\nPipe cutter 50 mm - 02,\r\nNose pliers - 02,\r\nCable cutter -02,\r\nAnti Cutter -02,\r\nHeavy duty diagonal pliers 7'''' -02,\r\nSpirit level - 02,\r\nCombination pliers -02,\r\nCombination Wrench (set 7 pcs) - 02,\r\nHack Saw blade with frame -02,\r\nHammer 1lbs - 02,\r\nLong arms ball point hex (Lock  & Key) Set - 02,\r\nCrimping Tools 0.5 - 4mm - 02,\r\nMeasuring Tape 08 meter - 02,\r\nDigital multimeter - 02,\r\nTin cutter - 02\r\n', '24/03/2016', 2, 2),
(268, 218, 68, 69, 140, 1, '2016-03-28', 0, '2016-03-30', 'One tool box contains following items:\r\nCommode pumping  - 02,\r\nPipe cleaner- 02,\r\nPipe cutter 2- 3/4''''- 01,\r\nPipe cutter 1/8''''-1- 5/4''''- 01,\r\nPipe wrench 14"- 02,\r\nAdjustable wrench 10"- 02,\r\nScrew driver (Set of 6)- 02,\r\nFile  &#40;Set of 6&#41;- 02,\r\nHandle strap wrench- 02,\r\nBasin wrench- 02,\r\nWater pump pliers- 02,\r\nHack Saw blade with frame- 02\r\n', '24/03/2016', 2, 2),
(269, 218, 68, 103, 142, 1, '2016-03-28', 0, '2016-04-05', 'Complete ', '24/03/2016', 5, 5),
(270, 218, 68, 70, 132, 1, '2016-03-30', 0, '2016-04-05', '(Makita) Model: N5900B', '24/03/2016', 4, 4),
(271, 218, 81, 88, 59, 1, '2016-04-07', 0, NULL, 'Type Kuwait ', '05/04/2016', 10, 10),
(272, 218, 100, 101, 146, 1, '2016-04-07', 0, NULL, 'Plastic type', '05/04/2016', 10, 10),
(273, 218, 100, 101, 64, 1, '2016-04-07', 0, NULL, 'Safety', '05/04/2016', 10, 10),
(274, 218, 68, 70, 144, 1, '2016-04-07', 0, NULL, 'Kaise (SK-3502)', '05/04/2016', 1, 1),
(275, 218, 76, 78, 143, 1, '2016-04-07', 0, NULL, 'Service color', '23/03/2016', 3, 3),
(276, 218, 100, 101, 61, 1, '2016-04-07', 0, NULL, 'Black', '05/04/2016', 10, 10),
(277, 218, 68, 70, 119, 1, '2016-04-07', 0, NULL, 'Digital camera', '07/04/2016', 5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `sa_item`
--

CREATE TABLE IF NOT EXISTS `sa_item` (
  `fld_id` int(11) NOT NULL AUTO_INCREMENT,
  `fld_item_name` varchar(200) NOT NULL,
  `fld_description` text NOT NULL,
  `fld_unit` int(5) NOT NULL,
  `fld_type` mediumint(8) NOT NULL,
  `fld_cre_by` tinyint(4) NOT NULL,
  `fld_cre_date` varchar(20) NOT NULL,
  `fld_upd_by` tinyint(4) NOT NULL,
  `fld_upd_date` date NOT NULL,
  `fld_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Record Status 1= Active, 0=Inactive',
  `fld_ledger_page` int(20) DEFAULT NULL,
  PRIMARY KEY (`fld_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=147 ;

--
-- Dumping data for table `sa_item`
--

INSERT INTO `sa_item` (`fld_id`, `fld_item_name`, `fld_description`, `fld_unit`, `fld_type`, `fld_cre_by`, `fld_cre_date`, `fld_upd_by`, `fld_upd_date`, `fld_active`, `fld_ledger_page`) VALUES
(4, 'Laptop', 'Dell Inspiron Mini\r\nBlack', 213, 216, 1, '01/04/0002', 0, '2016-03-06', 0, 1),
(5, 'Adjustable  punch machine', 'Adjustable  punch machine', 213, 216, 1, '2016-02-28', 0, '2016-03-06', 0, 1),
(6, 'Adjustable wrench', 'Adjustable wrench 1 set =3 pcs', 213, 216, 1, '2016-02-28', 0, '2016-03-06', 0, 2),
(7, 'Hacksaw blade', 'Hacksaw blade', 217, 216, 1, '2016-02-28', 0, '2016-03-06', 0, 3),
(8, 'Hammer Drill machine ', 'Hammer Drill machine ', 213, 216, 1, '2016-02-28', 0, '2016-03-06', 0, 4),
(9, 'Drill Bit', 'Hammer Drill machine  Size 6 to 14 ', 217, 216, 1, '2016-02-28', 0, '2016-03-06', 0, 5),
(10, 'Anti cutter with blade', 'Anti cutter with blade', 213, 215, 1, '2016-02-28', 0, '2016-03-06', 0, 6),
(11, 'Cutting players', 'Cutting players', 213, 216, 1, '2016-02-28', 0, '2016-03-06', 0, 10),
(12, 'Screw Driver', 'Screw Driver star & flat = 6 pcs', 217, 216, 1, '2016-02-28', 0, '2016-03-06', 0, 7),
(13, 'Ball pin hammer (size 1/2,1)Ibs', 'Ball pin hammer (size 1/2,1)Ibs', 213, 216, 1, '2016-02-28', 0, '2016-03-06', 0, 8),
(15, 'Insulation tape', 'Insulation tape', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 11),
(19, 'Iron drill bits', 'Iron drill bits', 217, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 14),
(21, 'Printer ', 'Printer', 213, 216, 1, '2016-02-29', 0, '2016-03-13', 0, 2),
(22, 'Desktop computer All in one', 'Desktop computer All in one', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 3),
(23, 'Photocopyer KYOCRA ', 'Photocopyer KYOCRA', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 4),
(24, 'Commercial paper shredder', 'Commercial paper shredder', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 5),
(25, 'Calculator', 'Calculator', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 6),
(26, 'Desk set', 'Desk set', 217, 215, 1, '2016-02-29', 0, '2016-03-13', 0, 7),
(27, 'File cover punch type', 'File cover punch type', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 8),
(28, 'Stapler ', 'Stapler ', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 9),
(29, 'Pen drive ', 'Pen drive ', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 11),
(31, 'Wirless mouse ', 'Wirless mouse ', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 13),
(32, 'Multiplug ', 'Multiplug ', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 14),
(34, 'Telephone set', 'Telephone set', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 15),
(35, 'Computer HP', 'Computer HP', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 16),
(40, 'Cup board ', 'Cup board ', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 21),
(41, 'Bed ', 'Bed', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 22),
(43, 'Pillow and case', 'Pillow and case', 219, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 24),
(44, 'Matress/Zazim', 'Matress/Zazim', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 25),
(45, 'Bed sheet', 'Bed sheet', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 26),
(46, 'Table officers ', 'Table officers ', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 27),
(47, 'Side rack', 'Side rack', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 28),
(48, 'Almirah ', 'Almirah ', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 29),
(49, 'Chair officers ', 'Chair officers ', 213, 216, 1, '2016-02-29', 0, '2016-03-03', 0, 30),
(50, 'Table steel Fram top board ', 'Table steel fram top board ', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 31),
(51, 'Table white ', 'Table white ', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 32),
(52, 'Alyen key ', 'Alyen key ', 219, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 33),
(53, 'Tape measurment 30 Ft', 'Tape measurment 30 Ft', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 34),
(54, 'Jeep', 'Mitsubishi ', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 35),
(56, 'Jacket combat ', 'Jaket combat ', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 2),
(57, 'Cap combat ', 'Cap combat ', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 3),
(58, 'Desart boot', 'Desart boot', 213, 215, 1, '2016-02-29', 0, '2016-03-13', 0, 4),
(59, 'Over all cmbination', 'Over all cmbination', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 5),
(60, 'Shoes Oxford black ', 'Shoes Oxford black ', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 6),
(61, 'Safety shoes ', 'Safety shoes ', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 7),
(62, 'Vest cotton', 'Vest cotton', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 8),
(63, 'Hand gloves ', 'Hand gloves ', 219, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 9),
(64, 'Sun glass ', 'Sun glass ', 213, 216, 1, '2016-02-29', 0, '2016-03-06', 0, 10),
(65, 'Golden Tag', 'Golden Tag', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 11),
(66, 'Belt lylon', 'Belt lylon', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 12),
(67, 'Hard belt black', 'Hard belt black', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 13),
(68, 'Leadership cap winter', 'Leadership cap winter', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 14),
(69, 'Olive short coat', 'Olive short coat', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 15),
(70, 'Olive green uniform shirt summer ', 'Olive  green uniform shirt summer', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 16),
(71, 'Olive green uniform shirt winter', 'Olive green uniform shirt winter', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 17),
(72, 'Badges ', 'Badges ', 219, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 18),
(73, 'Jersey pull over ', 'Jersey pull over ', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 19),
(74, 'Brown cap', 'Brown cap', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 20),
(76, 'Black tie', 'Black tie', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 21),
(77, 'Olive pant winter', 'Olive pant winter', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 23),
(78, 'Green socks ', 'Green socks ', 219, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 24),
(79, 'Desital Def jacket', 'Desital Def jacket', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 26),
(80, 'Olive green winter uniform ', 'Olive green winter uniform ', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 27),
(81, 'Olive green summer uniform ', 'Olive green summer uniform ', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 28),
(82, 'Black cap ', 'Black cap ', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 29),
(83, 'Vest Olive ', 'Vest Olive ', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 30),
(84, 'Olive pant summer ', 'Olive pant summer ', 213, 215, 1, '2016-02-29', 0, '2016-03-03', 0, 22),
(85, 'Winter shirt cold weather ', 'Winter shirt cold weather ', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 37),
(86, 'Full sleeve green jacket M/W', 'Full sleeve green jacket M/W', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 38),
(87, 'Trouser black ', 'Trouser black ', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 39),
(88, 'Red west coat ', 'Red west coat ', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 40),
(89, 'Shirt white', 'Shirt white', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 41),
(90, 'Black babun', 'Black babun', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 42),
(91, 'Black socks', 'Black socks', 219, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 25),
(92, 'Print trouser', 'Print trouser', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 44),
(93, 'Aproon white cook', 'Aproon white cook', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 45),
(94, 'Waiter Apron (White recxin  type)', 'Waiter  Apron (White recxin  type)', 213, 215, 1, '2016-02-29', 0, '2016-03-07', 0, 46),
(95, 'Coat white cook', 'Coat white cook', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 47),
(97, 'Anti cutter  ', 'Anti cutter  ', 213, 215, 1, '2016-02-29', 0, '0000-00-00', 0, NULL),
(98, 'Scissor ', 'Scissor ', 213, 215, 1, '2016-02-29', 0, '0000-00-00', 0, NULL),
(101, 'Pencil cutter', 'Pencil cutter (Big)', 213, 216, 1, '2016-02-29', 0, '0000-00-00', 0, NULL),
(103, 'Box file', 'Box file', 213, 215, 1, '2016-02-29', 0, '0000-00-00', 0, NULL),
(105, 'Stapler heavy duty', 'Stapler heavy duty', 213, 216, 1, '2016-02-29', 0, '0000-00-00', 0, NULL),
(106, 'Scale 30 cm', 'Scale 30 cm', 213, 216, 1, '2016-02-29', 0, '0000-00-00', 0, NULL),
(110, 'Punch 2 hole', 'Punch 2 hole', 213, 215, 1, '2016-02-29', 0, '0000-00-00', 0, NULL),
(112, 'File cover', 'File cover', 213, 215, 1, '2016-02-29', 0, '2016-03-06', 0, 10),
(115, 'Blankets ', 'ashes Cooler ', 213, 215, 1, '2016-03-03', 0, '2016-03-06', 0, 23),
(116, 'USB Cord turminator', 'Use Printer (White)', 213, 216, 1, '2016-03-06', 0, '2016-03-06', 0, 12),
(117, 'Olive shirt summer ', 'Officer''s Only', 213, 215, 1, '2016-03-06', 0, '0000-00-00', 0, 36),
(118, 'Black shoe', 'officer''s Only', 219, 215, 1, '2016-03-06', 0, '0000-00-00', 0, 43),
(119, 'Digital Camera ', 'Panasonic (made in China) Model : DMC-FZ70', 213, 216, 1, '2016-03-08', 0, '0000-00-00', 0, 42),
(120, 'Scanner plustek', 'serial No- 555j5b002007 Made in China', 213, 216, 1, '2016-03-08', 0, '0000-00-00', 0, 41),
(121, 'Computer Lenovo', 'Monitor (orca 28") All Accessory ', 219, 216, 1, '2016-03-16', 0, '0000-00-00', 0, 3),
(122, 'Printer coller(Ecosys Kyocera )', 'For Design( Ecosys Hyocera )', 213, 216, 1, '2016-03-16', 0, '2016-03-16', 0, 2),
(123, 'Telephone ', 'Panasonic M/No: 3 X KXT7730X & 2 X KXT7705X', 223, 216, 1, '2016-03-16', 0, '0000-00-00', 0, 15),
(124, 'Telephone Receiver ', 'M/No: KXTEX824', 223, 216, 1, '2016-03-16', 0, '0000-00-00', 0, 36),
(125, 'Trouser Combat', 'Service colour  ', 223, 215, 1, '2016-03-22', 0, '0000-00-00', 0, 1),
(126, 'Generator  ', '4.5 KVA ', 223, 216, 1, '23/03/2016', 0, '0000-00-00', 0, 43),
(127, 'Drill Machine (Battery Type)', ' Model: GSR-1800LI Professional\r\n Made in  Malaysia ', 223, 216, 1, '24/03/2016', 0, '0000-00-00', 0, 44),
(128, 'Hand Grinding Machine (Makita)', 'Model: 9553HN, Made in Japan,100 mm Dia ', 223, 216, 1, '24/03/2016', 0, '0000-00-00', 0, 45),
(129, 'Hammer Drill machine (makita)', 'HP 1630,710 watt,Made in Romania ', 223, 216, 1, '24/03/2016', 0, '0000-00-00', 0, 46),
(130, 'RAF Tools Combination Model: C100A set ', '100 PCS', 219, 216, 1, '24/03/2016', 0, '0000-00-00', 0, 41),
(131, 'Welding Machine 250 AMP', 'ARC', 223, 216, 1, '24/03/2016', 0, '0000-00-00', 0, 47),
(132, 'Circular Saw', 'Model: N5900B,  2000Watt, 235mm, made in Chaina', 223, 216, 1, '24/03/2016', 0, '0000-00-00', 0, 48),
(134, 'Anti Virus ', 'Quick heal', 223, 216, 1, '24/03/2016', 0, '0000-00-00', 0, 49),
(135, 'Wi Fi  Adapter ', 'D-Link', 223, 216, 1, '24/03/2016', 0, '0000-00-00', 0, 50),
(137, 'Mechanical Tools Box ', 'Complete set', 217, 216, 1, '24/03/2016', 0, '0000-00-00', 0, 23),
(138, 'Building Materials tools Box  ', 'Complete set ', 217, 216, 1, '24/03/2016', 0, '0000-00-00', 0, 24),
(139, 'Carpenter Tools Box ', 'Complete ', 217, 216, 1, '24/03/2016', 0, '0000-00-00', 0, 25),
(140, 'Pipe Fitter Tools Box', 'Compleate', 217, 216, 1, '24/03/2016', 0, '0000-00-00', 0, 26),
(141, 'Electrical Tools Box', 'Complete', 217, 216, 1, '24/03/2016', 0, '0000-00-00', 0, 27),
(142, 'Compound Meter Saw ', 'Complete Set', 223, 216, 1, '24/03/2016', 0, '0000-00-00', 0, 1),
(143, 'BA-21978 ,21980,21983 Bus 56 seater international blue bird', 'Service Color  ', 223, 216, 1, '23/03/2016', 0, '0000-00-00', 0, 37),
(144, 'Digital isulation tester', 'Chaina', 223, 216, 1, '23/03/2016', 0, '0000-00-00', 0, 56),
(146, 'Helmet ', 'Plastic type', 223, 216, 1, '24/02/2016', 0, '0000-00-00', 0, 49);

-- --------------------------------------------------------

--
-- Table structure for table `sa_lookup_data`
--

CREATE TABLE IF NOT EXISTS `sa_lookup_data` (
  `LOOKUP_DATA_ID` int(8) NOT NULL AUTO_INCREMENT COMMENT 'Primary key of sa_lookup_data table.',
  `LOOKUP_GRP_ID` tinyint(3) DEFAULT NULL,
  `LOOKUP_DATA_NAME` varchar(60) NOT NULL,
  `CHAR_LOOKUP` varchar(3) DEFAULT NULL,
  `NUMB_LOOKUP` float DEFAULT NULL,
  `ORDER_SL_NO` tinyint(3) NOT NULL,
  `UD_LKPDATA_ID` varchar(20) DEFAULT NULL COMMENT 'User Define Charge Head Id',
  `ACTIVE_FLAG` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Record Status 1= Active, 0=Inactive',
  `CRE_BY` int(10) unsigned DEFAULT NULL,
  `CRE_DT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UPD_BY` int(10) unsigned DEFAULT NULL,
  `UPD_DT` datetime DEFAULT NULL,
  PRIMARY KEY (`LOOKUP_DATA_ID`),
  KEY `FK01_LOOKUP_GRP_ID` (`LOOKUP_GRP_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Group wise detail data entry i.e Male, female for gender group ' AUTO_INCREMENT=235 ;

--
-- Dumping data for table `sa_lookup_data`
--

INSERT INTO `sa_lookup_data` (`LOOKUP_DATA_ID`, `LOOKUP_GRP_ID`, `LOOKUP_DATA_NAME`, `CHAR_LOOKUP`, `NUMB_LOOKUP`, `ORDER_SL_NO`, `UD_LKPDATA_ID`, `ACTIVE_FLAG`, `CRE_BY`, `CRE_DT`, `UPD_BY`, `UPD_DT`) VALUES
(209, 46, 'Ton', 'Ton', 0, 0, NULL, 1, NULL, '2016-02-16 03:55:26', NULL, NULL),
(210, 46, 'Kg', 'Kg', 0, 0, NULL, 1, NULL, '2016-02-16 03:55:26', NULL, NULL),
(211, 46, 'Pound', 'Pou', 0, 0, NULL, 1, NULL, '2016-02-16 06:00:26', NULL, NULL),
(212, 46, 'Tonne', 'Ton', 0, 0, NULL, 1, NULL, '2016-02-16 06:11:02', NULL, NULL),
(213, 46, 'Piece', 'pie', 0, 0, NULL, 1, NULL, '2016-02-17 02:51:50', NULL, NULL),
(214, 46, 'Truck', 'Tru', 0, 0, NULL, 1, NULL, '2016-02-18 04:19:20', NULL, NULL),
(215, 48, 'Consumable', 'Con', 0, 0, NULL, 1, NULL, '2016-02-18 11:06:45', NULL, NULL),
(216, 48, 'Inconsumable', 'Ico', 0, 0, NULL, 1, NULL, '2016-02-18 11:07:15', NULL, NULL),
(217, 46, 'Box', 'box', 0, 0, NULL, 1, NULL, '2016-02-18 11:44:03', NULL, NULL),
(218, 49, 'Central Store', 'STO', 0, 0, NULL, 1, NULL, '2016-02-23 06:51:25', NULL, NULL),
(219, 46, 'Set', 'Set', 0, 0, NULL, 1, NULL, '2016-02-29 04:57:02', NULL, NULL),
(220, 46, 'Pairs', 'Pai', 0, 0, NULL, 1, NULL, '2016-02-29 06:07:46', NULL, NULL),
(221, 46, 'Packet', 'pac', 0, 0, NULL, 1, NULL, '2016-02-29 06:08:50', NULL, NULL),
(222, 46, 'Rim', 'rim', 0, 0, NULL, 1, NULL, '2016-03-01 06:18:01', NULL, NULL),
(223, 46, 'Nos', 'Nos', 0, 0, NULL, 1, NULL, '2016-03-01 06:18:05', NULL, NULL),
(224, 46, 'Rim', 'rim', 0, 0, NULL, 1, NULL, '2016-03-01 06:18:08', NULL, NULL),
(225, 46, 'Rim', 'rim', 0, 0, NULL, 1, NULL, '2016-03-01 06:18:09', NULL, NULL),
(226, 46, 'Rim', 'rim', 0, 0, NULL, 1, NULL, '2016-03-01 06:18:09', NULL, NULL),
(227, 46, 'Rim', 'rim', 0, 0, NULL, 1, NULL, '2016-03-01 06:18:21', NULL, NULL),
(228, 46, 'Rim', 'rim', 0, 0, NULL, 1, NULL, '2016-03-01 06:18:23', NULL, NULL),
(229, 46, 'Rim', 'rim', 0, 0, NULL, 1, NULL, '2016-03-01 06:18:30', NULL, NULL),
(230, 46, 'Rim', 'rim', 0, 0, NULL, 0, NULL, '2016-03-01 06:19:11', NULL, NULL),
(231, 46, 'Rim', 'rim', 0, 0, NULL, 0, NULL, '2016-03-01 06:19:27', NULL, NULL),
(232, 46, 'Rim', 'rim', 0, 0, NULL, 0, NULL, '2016-03-01 06:19:33', NULL, NULL),
(233, 50, 'Admin', 'a', 0, 0, NULL, 1, NULL, '2016-03-19 12:35:05', NULL, NULL),
(234, 50, 'User', 'u', 0, 0, NULL, 1, NULL, '2016-03-19 12:35:14', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sa_lookup_grp`
--

CREATE TABLE IF NOT EXISTS `sa_lookup_grp` (
  `LOOKUP_GRP_ID` tinyint(3) NOT NULL AUTO_INCREMENT COMMENT 'Primary key of sa_lookup_grp table.',
  `LOOKUP_GRP_NAME` varchar(50) NOT NULL,
  `GRP_CATEGORY` tinyint(2) DEFAULT NULL,
  `USE_CHAR_NUMB` varchar(1) DEFAULT 'N',
  `SYSTEM_FG` tinyint(1) DEFAULT '0',
  `INSERT_FG` tinyint(1) DEFAULT '0',
  `UPDATE_FG` tinyint(1) DEFAULT '0',
  `DELETE_FG` tinyint(1) DEFAULT '0',
  `ORDER_SL_NO` tinyint(3) NOT NULL,
  `UD_LKPGRP_ID` varchar(20) DEFAULT NULL COMMENT 'User Define Charge Head Id',
  `ACTIVE_FLAG` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Record Status 1= Active, 0=Inactive',
  `CRE_BY` int(10) unsigned DEFAULT NULL,
  `CRE_DT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UPD_BY` int(10) unsigned DEFAULT NULL,
  `UPD_DT` datetime DEFAULT NULL,
  PRIMARY KEY (`LOOKUP_GRP_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='All master data group entry i.e. Gender, supplier type ' AUTO_INCREMENT=51 ;

--
-- Dumping data for table `sa_lookup_grp`
--

INSERT INTO `sa_lookup_grp` (`LOOKUP_GRP_ID`, `LOOKUP_GRP_NAME`, `GRP_CATEGORY`, `USE_CHAR_NUMB`, `SYSTEM_FG`, `INSERT_FG`, `UPDATE_FG`, `DELETE_FG`, `ORDER_SL_NO`, `UD_LKPGRP_ID`, `ACTIVE_FLAG`, `CRE_BY`, `CRE_DT`, `UPD_BY`, `UPD_DT`) VALUES
(46, 'UOM', NULL, 'C', 0, 0, 0, 0, 0, NULL, 1, NULL, '2016-02-16 03:51:26', NULL, NULL),
(48, 'Item Type ', NULL, 'C', 0, 0, 0, 0, 0, NULL, 0, NULL, '2016-02-18 11:06:18', NULL, NULL),
(49, 'Store', NULL, 'C', 0, 0, 0, 0, 0, NULL, 0, NULL, '2016-02-23 06:50:39', NULL, NULL),
(50, 'User Type', NULL, 'C', 0, 0, 0, 0, 0, NULL, 0, NULL, '2016-03-19 12:34:55', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_item`
--

CREATE TABLE IF NOT EXISTS `tbl_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `item_quantity` int(11) NOT NULL,
  `fld_unit` int(5) NOT NULL,
  `fld_type` mediumint(8) NOT NULL,
  `cre_by` tinyint(4) NOT NULL,
  `cre_date` date NOT NULL,
  `upd_by` tinyint(4) NOT NULL,
  `upd_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=121 ;

--
-- Dumping data for table `tbl_item`
--

INSERT INTO `tbl_item` (`id`, `parent_id`, `category_id`, `item_name`, `description`, `item_quantity`, `fld_unit`, `fld_type`, `cre_by`, `cre_date`, `upd_by`, `upd_date`) VALUES
(77, 52, 66, 'Computer', '', 8, 213, 215, 0, '2016-02-16', 0, '2016-02-18'),
(80, 76, 79, 'Green Light', 'This is green Light', 50, 213, 215, 0, '2016-02-18', 0, '2016-02-17'),
(83, 52, 53, 'Laptop', '', 6, 213, 215, 0, '2016-02-16', 0, '2016-02-18'),
(100, 52, 66, 'Mobile', '', 2, 213, 216, 0, '2016-02-17', 0, '0000-00-00'),
(101, 76, 79, 'Plumbing', '', 65, 213, 215, 0, '2016-02-18', 0, '2016-02-18'),
(102, 76, 79, 'Motorcycle', '', 48, 213, 216, 0, '2016-02-18', 0, '2016-02-18'),
(105, 76, 78, 'Car', '', 16, 213, 216, 0, '2016-02-18', 0, '2016-02-18'),
(106, 72, 73, 'Rod', '', 32, 209, 215, 0, '2016-02-18', 0, '2016-02-18'),
(107, 72, 73, 'Bali', 'Bali', 55, 214, 215, 0, '2016-02-18', 0, '2016-02-18'),
(113, 72, 74, 'Key borad', 'Key borad', 290, 213, 215, 0, '2016-02-18', 0, '2016-02-18'),
(114, 0, 0, 'Computer', 'Core I5', 50, 213, 0, 0, '2016-02-18', 0, '0000-00-00'),
(115, 52, 53, 'Pen', 'Pen', 100, 213, 0, 0, '2016-02-18', 0, '0000-00-00'),
(116, 68, 70, 'Pen', 'Pen', 30, 213, 0, 0, '2016-02-18', 0, '0000-00-00'),
(117, 0, 0, 'laptop', 'dell', 50, 213, 0, 0, '2016-02-21', 0, '0000-00-00'),
(118, 0, 0, 'WWWWWWW', 'YYYYYYY', 10, 213, 0, 0, '2016-02-21', 0, '0000-00-00'),
(119, 52, 66, 'PAPER', 'A4', 10, 213, 0, 0, '2016-02-21', 0, '0000-00-00'),
(120, 0, 0, 'Chair Easy', 'Use for only CO', 1, 213, 0, 0, '2016-03-03', 0, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tree_variant`
--

CREATE TABLE IF NOT EXISTS `tbl_tree_variant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `level` tinyint(4) NOT NULL,
  `colorpicker` varchar(255) NOT NULL,
  `manufacturer` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `unit` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=104 ;

--
-- Dumping data for table `tbl_tree_variant`
--

INSERT INTO `tbl_tree_variant` (`id`, `parent_id`, `name`, `level`, `colorpicker`, `manufacturer`, `type`, `unit`, `status`) VALUES
(51, 0, 'Main Menu', 1, '#0000ff', '', '', 0, 1),
(52, 51, 'Office', 2, '', '', '', 0, 0),
(53, 52, 'Equipment', 3, '#f2f2f2, #f5768f, #69d88a', '', '', 0, 0),
(54, 52, 'Furniture', 3, '#d1f2ce', '', '', 0, 0),
(66, 52, 'Stationary', 3, '#00ffff', 'Baximco', 'tablet', 127, 0),
(68, 51, 'Tools', 2, '', '', '', 0, 0),
(69, 68, 'Building Materials', 3, '', '', '', NULL, 0),
(70, 68, 'Electrical ', 3, '', '', '', NULL, 0),
(72, 51, 'Materials', 2, '', '', '', 0, 0),
(73, 72, 'Building & Roads', 3, '', '', '', NULL, 0),
(74, 72, 'Electrical & Mechanical', 3, '', '', '', NULL, 0),
(76, 51, 'Vehicles', 2, '', '', '', 0, 0),
(77, 76, 'Light Vehicles', 3, '', '', '', 0, 0),
(78, 76, 'Medium Vehicles', 3, '', '', '', 0, 0),
(79, 76, 'Heavy Vehicles', 3, '', '', '', 0, 0),
(80, 76, 'Plant', 3, '', '', '', 0, 0),
(81, 51, 'Clothings', 2, '', '', '', NULL, 0),
(83, 81, 'Foot Wear', 3, '', '', '', NULL, 0),
(88, 81, 'Uniform', 3, '', '', '', NULL, 0),
(89, 81, 'Misc', 3, '', '', '', NULL, 0),
(91, 90, 'Office', 3, '', '', '', NULL, 0),
(92, 90, 'Tools', 3, '', '', '', NULL, 0),
(94, 81, 'Safety Wear', 3, '', '', '', NULL, 0),
(96, 51, 'Equipment', 0, '', '', '', NULL, 0),
(97, 96, 'Building & Roads', 0, '', '', '', NULL, 0),
(98, 97, 'Electrical & mechanical ', 0, '', '', '', NULL, 0),
(99, 66, 'Computer', 0, '', '', '', NULL, 0),
(100, 51, 'Safety Gear', 0, '', '', '', NULL, 0),
(101, 100, 'Safety Gear', 0, '', '', '', NULL, 0),
(102, 70, 'Mechanical', 0, '', '', '', NULL, 0),
(103, 102, 'Carpenter', 0, '', '', '', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_types`
--

CREATE TABLE IF NOT EXISTS `tbl_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `status` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `tbl_types`
--

INSERT INTO `tbl_types` (`id`, `name`, `status`) VALUES
(1, 'tablet', 0),
(2, 'Serup', 0),
(6, 'ddd', 0),
(9, 'pp', 0),
(11, 'dsfsdf', 0),
(14, 'bangladesh', 0),
(16, 'ddddd', 0),
(21, 'ddddswww', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(35) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `fullName` varchar(20) DEFAULT NULL,
  `active_status` tinyint(4) DEFAULT NULL,
  `user_type` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `password`, `status`, `fullName`, `active_status`, `user_type`) VALUES
(1, 'admin', '202cb962ac59075b964b07152d234b70', 1, 'Admin', 1, 233),
(2, 'construction', '202cb962ac59075b964b07152d234b70', 2, 'Project', 1, 233),
(3, 'repair', '202cb962ac59075b964b07152d234b70', 3, 'Maintenance', 1, 234),
(4, 'design', '202cb962ac59075b964b07152d234b70', 4, 'Design Cell', 1, 234),
(5, 'headquarter', '202cb962ac59075b964b07152d234b70', 5, 'Headquarter', 1, 234);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
